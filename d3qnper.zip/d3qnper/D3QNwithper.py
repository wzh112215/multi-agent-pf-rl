import torch
import torch.nn as nn
import torch.optim as optim
import torch.nn.functional as F
from collections import namedtuple, deque
import random
import math
import numpy as np

tau = 0.005

# Transition tuple: (state, action, next_state, reward)
Transition = namedtuple('Transition', ('state', 'action', 'next_state', 'reward'))

class ReplayMemory:
    def __init__(self, capacity):
        self.memory = deque([], maxlen=capacity)
    def push(self, *args):
        self.memory.append(Transition(*args))
    def sample(self, batch_size):
        return random.sample(self.memory, batch_size)
    def __len__(self):
        return len(self.memory)

class PrioritizedReplayMemory:
    def __init__(self, capacity, alpha=0.6):
        self.capacity = capacity
        self.alpha = alpha
        self.memory = []
        self.priorities = np.zeros((capacity,), dtype=np.float32)
        self.pos = 0

    def __len__(self):
        return len(self.memory)

    def push(self, *args):
        max_prio = self.priorities.max() if self.memory else 1.0
        if len(self.memory) < self.capacity:
            self.memory.append(Transition(*args))
        else:
            self.memory[self.pos] = Transition(*args)
        self.priorities[self.pos] = max_prio
        self.pos = (self.pos + 1) % self.capacity

    def sample(self, batch_size, beta=0.4):
        valid_len = len(self.memory)
        prios = self.priorities[:valid_len]

        probs = prios ** self.alpha
        probs_sum = probs.sum()
        if probs_sum == 0 or not np.isfinite(probs_sum):
            probs = np.ones_like(probs) / valid_len
        else:
            probs = probs / probs_sum

        replace = valid_len < batch_size
        indices = np.random.choice(valid_len, batch_size, p=probs, replace=replace)
        samples = [self.memory[idx] for idx in indices]

        weights = (valid_len * probs[indices]) ** (-beta)
        weights = weights / weights.max()

        return samples, indices, weights

    def update_priorities(self, indices, new_priorities):
        for idx, prio in zip(indices, new_priorities):
            p = float(prio)
            if not np.isfinite(p): p = 1.0
            self.priorities[idx] = max(p, 1e-6)

class DQN(nn.Module):
    def __init__(self, n_observations, n_actions):
        super(DQN, self).__init__()
        self.fc1 = nn.Linear(n_observations, 2500)
        self.fc2 = nn.Linear(2500, 2500)
        self.value_stream = nn.Linear(2500, 1)
        self.advantage_stream = nn.Linear(2500, n_actions)

    def forward(self, x):
        x = F.relu(self.fc1(x))
        x = F.relu(self.fc2(x))
        value = self.value_stream(x)          # [B, 1]
        advantage = self.advantage_stream(x)  # [B, A]
        q_values = value + advantage - advantage.mean(dim=1, keepdim=True)
        return q_values  # [B, A]

class DQNAgent:
    def __init__(self, n_observations, n_actions, device,
                 memory_capacity, batch_size, gamma, lr,
                 eps_start, eps_end, eps_decay, tau, goal_prob):
        self.n_actions = n_actions
        self.device = device
        self.batch_size = batch_size
        self.gamma = gamma
        self.lr = lr
        self.eps_start = eps_start
        self.eps_end = eps_end
        self.eps_decay = eps_decay
        self.tau = tau
        self.goal_prob = goal_prob

        self.steps_done = 0

        self.policy_net = DQN(n_observations, n_actions).to(device)
        self.target_net = DQN(n_observations, n_actions).to(device)
        self.target_net.load_state_dict(self.policy_net.state_dict())
        self.target_net.eval()

        self.optimizer = optim.AdamW(self.policy_net.parameters(), lr=lr, amsgrad=True)

        self.memory = PrioritizedReplayMemory(memory_capacity, alpha=0.6)
        self.per_beta_start = 0.4
        self.per_beta_frames = 100_000
        self.per_eps = 1e-5

    def _per_beta(self):
        t = min(1.0, self.steps_done / float(self.per_beta_frames))
        return self.per_beta_start + t * (1.0 - self.per_beta_start)

    def select_action(self, state, agent_pos, goal):
        eps_threshold = self.eps_end + (self.eps_start - self.eps_end) * \
            math.exp(-1. * self.steps_done / self.eps_decay)
        self.steps_done += 1

        if random.random() > eps_threshold:
            with torch.no_grad():
                return self.policy_net(state).max(1).indices.view(1, 1)
        else:
            if np.random.rand() < self.goal_prob:
                distances = np.zeros(4)
                goal_pos = np.array([goal[0], goal[1]])
                directions = [np.array([0, 1]), np.array([0, -1]), np.array([-1, 0]), np.array([1, 0])]
                for idx, d in enumerate(directions):
                    distances[idx] = np.linalg.norm(agent_pos + d - goal_pos)
                return torch.tensor([[np.argmin(distances)]], device=self.device, dtype=torch.long)
            else:
                return torch.tensor([[random.randint(0, self.n_actions - 1)]], device=self.device, dtype=torch.long)

    def optimize_model(self):
        if len(self.memory) < self.batch_size:
            return

        beta = self._per_beta()
        transitions, indices, is_weights_np = self.memory.sample(self.batch_size, beta=beta)

        batch = Transition(*zip(*transitions))

        non_final_mask = torch.tensor(
            tuple(map(lambda s: s is not None, batch.next_state)),
            device=self.device, dtype=torch.bool
        )
        non_final_next_states = torch.cat([s for s in batch.next_state if s is not None])

        state_batch  = torch.cat(batch.state)
        action_batch = torch.cat(batch.action)
        reward_batch = torch.cat(batch.reward)

        state_action_values = self.policy_net(state_batch).gather(1, action_batch)  # [B,1]

        next_state_values = torch.zeros(self.batch_size, device=self.device)
        with torch.no_grad():
            next_actions = self.policy_net(non_final_next_states).max(1).indices.unsqueeze(1)
            next_q_values = self.target_net(non_final_next_states).gather(1, next_actions).squeeze(1)
            next_state_values[non_final_mask] = next_q_values

        expected_state_action_values = reward_batch + (self.gamma * next_state_values)

        target_unsq = expected_state_action_values.unsqueeze(1) if expected_state_action_values.dim() == 1 else expected_state_action_values
        per_sample_loss = F.smooth_l1_loss(state_action_values, target_unsq, reduction='none').squeeze(1)  # [B]

        is_weights = torch.tensor(is_weights_np, device=self.device, dtype=torch.float32)  # [B]
        loss = (is_weights * per_sample_loss).mean()

        self.optimizer.zero_grad()
        loss.backward()
        torch.nn.utils.clip_grad_value_(self.policy_net.parameters(), 100)
        self.optimizer.step()

        with torch.no_grad():
            td_errors = (target_unsq.squeeze(1) - state_action_values.squeeze(1)).abs().detach().cpu().numpy()  # [B]
            new_prios = td_errors + self.per_eps
        self.memory.update_priorities(indices, new_prios)
    
    def soft_update_target_network(self):
        target_net_state_dict = self.target_net.state_dict()
        policy_net_state_dict = self.policy_net.state_dict()
        for key in policy_net_state_dict:
            target_net_state_dict[key] = policy_net_state_dict[key] * self.tau + target_net_state_dict[key] * (1 - self.tau)
        self.target_net.load_state_dict(target_net_state_dict)
