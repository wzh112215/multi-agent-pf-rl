# Particle filter code structure based on chp 12 of Kalman and Bayesian Filters in Python by Roger R Labbe Jr.
# https://github.com/rlabbe/Kalman-and-Bayesian-Filters-in-Python/blob/master/12-Particle-Filters.ipynb

import numpy as np        # For array operations
import torch              # Torch (optional; used for tensor ops)
import random             # For random numbers
import math               # For math functions (sqrt, exp)

search_area_x = 50
search_area_y = 50

# === 1. Initialise particles randomly in search region ===

def create_uniform_particles(x_range, y_range, strength_range, no_sources_range, N):
    """
    Randomly generate N particles in the search region.
    Each particle may represent between min and max number of sources, with random (x, y, strength).
    Structure per particle row:
      [num_sources, x1, y1, s1, x2, y2, s2, ..., xk, yk, sk] padded with NaNs up to max allowed sources.
    """
    particles = np.full((N, 3 * no_sources_range[1] + 1), np.nan)

    for i in range(N):
        no_sources = random.randint(int(no_sources_range[0]), int(no_sources_range[1]))
        particles[i, 0] = no_sources

        for j in range(no_sources):
            particles[i, 3 * j + 1] = random.uniform(x_range[0], x_range[1])            # x
            particles[i, 3 * j + 2] = random.uniform(y_range[0], y_range[1])            # y
            particles[i, 3 * j + 3] = random.uniform(strength_range[0], strength_range[1])  # strength

    return particles

# Debugging: Initialise cheat particles at correct location

def create_cheat_particles(no_sources, source1, source2, source3, no_sources_range, N):
    """
    Create 'cheat' particles initialised at the ground-truth sources (for debugging/visual checks).
    Parameters:
      - no_sources: integer number of sources
      - source1, source2, source3: source objects with x(), y(), and source_radioactivity
      - no_sources_range: allowed range of sources per particle (min, max)
      - N: number of particles
    """
    # Row structure: (N_src, x1, y1, s1, ..., xN, yN, sN), padded with NaNs to max size.
    particles = np.full((N, 3 * no_sources_range[1] + 1), np.nan)  # Initialise with NaNs
    particles[:] = [
        no_sources,
        source1.x(), source1.y(), source1.source_radioactivity,
        source2.x(), source2.y(), source2.source_radioactivity,
        source3.x(), source3.y(), source3.source_radioactivity,
        np.nan, np.nan, np.nan, np.nan, np.nan, np.nan
    ]
    return particles

# 2. No need for predict step as the source is static (position and strength)
# (half-life of sources markedly exceeds duration of localization)

# 3. Compute likelihood of particle representing the true state (source parameters)
#    given the observation (sensor reading), using posterior distribution
# Check distance between sources and send likelihood of predictions that predict sources within 5 m of each other to 0

def check_within_distance(coords, distance_threshold=5):
    """
    Check if any pair of points in coords is within distance_threshold (inclusive).
    coords: list of (x, y) or array of shape (n, 2)
    Returns True if any pair is too close, else False.
    """
    coords = np.array(coords)
    for i in range(len(coords)):
        for j in range(i + 1, len(coords)):
            distance = np.linalg.norm(coords[i] - coords[j])
            if distance <= distance_threshold:
                return True
    return False

def coordinates_out_of_bounds(coordinates, lower_bound=0, upper_bound=search_area_x):
    """
    Return True if any (x, y) in 'coordinates' lies outside [lower_bound, upper_bound].
    'coordinates' is array of shape (n, 2).
    """
    out_of_bounds = np.any(
        (coordinates[:, 0] < lower_bound) | (coordinates[:, 0] > upper_bound) |
        (coordinates[:, 1] < lower_bound) | (coordinates[:, 1] > upper_bound)
    )
    return out_of_bounds

def extract_source_coordinates(particle):  # To get source coordinates in a 2d array from the particle
    """
    Extract all (x, y) source coordinates from a particle row.
    Returns array of shape (num_sources, 2).
    """
    source_coordinates = []
    num_sources = int(particle[0])  # The first element is the number of sources

    # Extract x and y for each source
    for i in range(num_sources):
        x = particle[1 + 3 * i]  # x value is at 1 + 3*i
        y = particle[2 + 3 * i]  # y value is at 2 + 3*i
        source_coordinates.append([x, y])

    return np.array(source_coordinates)

def likelihood(agent_position, particles, measured_value, sd_noise_pct, min_radiation_level, max_radiation_level):
    """
    Compute per-particle likelihood for a single agent observation.
    Inputs:
      - agent_position: (x, y)
      - particles: array shape (N, M) with [num_sources, x1, y1, s1, ...]
      - measured_value: sensor reading at agent position
      - sd_noise_pct: stddev as percentage of predicted radiation
      - min_radiation_level, max_radiation_level: validity range for source strength
    Returns:
      - likelihood: array of shape (N,)
    """
    likelihood = np.empty(particles.shape[0])
    agent_x, agent_y = agent_position

    for i, particle in enumerate(particles):
        particle_likelihood = 1.0
        num_sources = int(particle[0])
        total_radiation_level = 0

        for j in range(num_sources):
            x_src = particle[3 * j + 1]
            y_src = particle[3 * j + 2]
            strength = particle[3 * j + 3]

            dist = np.sqrt((agent_x - x_src) ** 2 + (agent_y - y_src) ** 2)
            if dist < 1:
                total_radiation_level += strength
            else:
                total_radiation_level += strength / dist ** 2

        sigmaN = max(sd_noise_pct * total_radiation_level, 1.e-300)

        prob = (1 / (np.sqrt(2 * np.pi * sigmaN ** 2))) * \
               np.exp(-((measured_value - total_radiation_level) ** 2) / (2 * sigmaN ** 2))

        particle_likelihood *= prob

        for j in range(num_sources):
            strength = particle[3 * j + 3]
            if strength < min_radiation_level or strength > max_radiation_level:
                particle_likelihood = 0

        two_d_particle = extract_source_coordinates(particle)

        if check_within_distance(two_d_particle, 5) or coordinates_out_of_bounds(two_d_particle):
            particle_likelihood = 0

        likelihood[i] = particle_likelihood

    return likelihood

# 4. Update weights for particles depending on their likelihood

def update_weights(weights_old, likelihood):
    """
    Bayesian weight update: new_weights ∝ old_weights * likelihood.
    Adds a tiny floor for numerical stability, then normalises.
    """
    weights_new = weights_old * likelihood
    weights_new += 1.e-300
    weights_new = weights_new / np.sum(weights_new)
    return weights_new

# 5. Compute source term (s) with current particles
def estimate(particles, weights):
    """
    Estimate source parameters (x, y, strength) from current particles and weights.
    Inputs:
      - particles: rows are [num_sources, x1, y1, s1, x2, y2, s2, ...]
      - weights: per-particle weights (sum to 1)
    Returns:
      - mean_x_pos, mean_y_pos, mean_strength, var_x_pos, var_y_pos, var_strength
        (lists padded with NaNs up to max sources)
    """
    max_no_sources = (particles.shape[1] - 1) / 3

    particles = torch.tensor(particles, dtype=torch.float32)
    weights = torch.tensor(weights, dtype=torch.float32)

    num_sources = particles[:, 0].int()
    mode_no_sources = np.bincount(num_sources.numpy()).argmax()

    filtered_particles = particles[num_sources == mode_no_sources]
    filtered_weights = weights[num_sources == mode_no_sources]

    mean_x_pos, mean_y_pos, mean_strength = [], [], []
    var_x_pos, var_y_pos, var_strength = [], [], []

    for source in range(mode_no_sources):
        x_vals = filtered_particles[:, 3 * source + 1]
        y_vals = filtered_particles[:, 3 * source + 2]
        strengths = filtered_particles[:, 3 * source + 3]

        mean_x = torch.sum(x_vals * filtered_weights) / torch.sum(filtered_weights)
        mean_y = torch.sum(y_vals * filtered_weights) / torch.sum(filtered_weights)
        mean_c = torch.sum(strengths * filtered_weights) / torch.sum(filtered_weights)

        var_x = torch.sum(filtered_weights * (x_vals - mean_x) ** 2) / torch.sum(filtered_weights)
        var_y = torch.sum(filtered_weights * (y_vals - mean_y) ** 2) / torch.sum(filtered_weights)
        var_c = torch.sum(filtered_weights * (strengths - mean_c) ** 2) / torch.sum(filtered_weights)

        mean_x_pos.append(mean_x.item())
        mean_y_pos.append(mean_y.item())
        mean_strength.append(mean_c.item())
        var_x_pos.append(var_x.item())
        var_y_pos.append(var_y.item())
        var_strength.append(var_c.item())
    
    missing_values = int(max_no_sources - mode_no_sources)

    mean_x_pos += [np.nan] * missing_values
    mean_y_pos += [np.nan] * missing_values
    mean_strength += [np.nan] * missing_values
    var_x_pos += [np.nan] * missing_values
    var_y_pos += [np.nan] * missing_values
    var_strength += [np.nan] * missing_values

    return mean_x_pos, mean_y_pos, mean_strength, var_x_pos, var_y_pos, var_strength
    

# 6. Resample particles if effective sample size is too small to represent true distribution
# Simple regularized resampling
def resampling_simple(particles, weights, min_no_sources, max_no_sources, min_radiation_level, max_radiation_level, EPS_START, EPS_END, EPS_DECAY, steps_done):
    """
    Simple regularised resampling with small perturbations for diversity.
    Triggers when ESS is low; also applies occasional structure changes (add/remove/scramble).
    """
    N = np.size(weights)

    # Effective sample size (ESS)
    ess = 1 / np.sum(weights**2)

    EPS_END = 0.10  # Maintain some diversity
    EPS_DECAY = 40000
    eps_threshold = EPS_END + (EPS_START - EPS_END) * math.exp(-1. * steps_done / EPS_DECAY)
    need_resample = ess < 0.5 * N

    no_sources_change_pct = 0.004 * eps_threshold  # Prob. to increase/decrease number of sources
    scramble_pct = 0.004 * eps_threshold          # Prob. to scramble strengths order

    if need_resample:
        particles_new = particles

        cumulative_sum = np.cumsum(weights)
        cumulative_sum[-1] = 1.
        indexes = np.searchsorted(cumulative_sum, np.random.random(N))

        particles_new = particles[indexes]

        unique_values = np.unique(particles_new[:, 0]).astype(int)

        grouped_particles = {}
        particles_result = np.array([])
        first_append = True

        for value in unique_values:
            matching_particles = particles_new[particles_new[:, 0] == value]
            grouped_particles[value] = matching_particles[:, 1:value*3 + 1]

        for no_sources, particle_array in grouped_particles.items():
            n_dim = no_sources * 3

            perturbations = np.random.normal(0, 0.5 * eps_threshold, (len(particle_array), n_dim))  # Perturbations decay over time
            grouped_particles[no_sources] = particle_array + perturbations

            if grouped_particles[no_sources].shape[1] < max_no_sources * 3:
                padding = np.full((grouped_particles[no_sources].shape[0],
                                   max_no_sources*3 - grouped_particles[no_sources].shape[1]), np.nan)
                grouped_particles[no_sources] = np.hstack((grouped_particles[no_sources], padding))

            no_sources_column = np.full((particle_array.shape[0], 1), no_sources)
            grouped_particles[no_sources] = np.hstack((no_sources_column, grouped_particles[no_sources]))
            particles = grouped_particles[no_sources]

            if first_append:
                particles_result = np.array(grouped_particles[no_sources])
                first_append = False
            else:
                particles_result = np.vstack((particles_result, grouped_particles[no_sources]))
                
        for i, particle in enumerate(particles_result):

            no_sources_change_prob = np.random.random()
            no_sources = int(particle[0])
                
            if 0 < no_sources_change_prob < no_sources_change_pct and no_sources < max_no_sources:  # Increase by 1
                particle[0] = no_sources + 1
                particle[3 * no_sources + 1] = np.random.uniform(0, search_area_x)
                particle[3 * no_sources + 2] = np.random.uniform(0, search_area_x)
                particle[3 * no_sources + 3] = np.random.uniform(min_radiation_level, max_radiation_level)
                    
            elif no_sources_change_pct < no_sources_change_prob < no_sources_change_pct*2 and no_sources > min_no_sources:  # Decrease by 1
                no_sources = int(particle[0])

                particle_new = particle[:no_sources*3 + 1]

                sources = particle_new[1:].reshape(no_sources, 3)  # (x, y, strength)

                x1, y1, str1 = sources[0]
            
                distances = np.linalg.norm(sources[1:, :2] - np.array([x1, y1]), axis=1)  # Only use x and y

                closest_index = np.argmin(distances) + 1  # skip the first source

                sources = np.delete(sources, closest_index, axis=0)

                for i2 in range(6 - no_sources):
                    sources = np.vstack([sources, [np.nan, np.nan, np.nan]])

                particle[1:] = sources.flatten()
                particle[0] = no_sources - 1
            
            elif no_sources_change_pct*2 < no_sources_change_prob < no_sources_change_pct*2 + scramble_pct and no_sources > min_no_sources:
                no_sources = int(particle[0])

                particle_new = particle[:no_sources*3 + 1]

                str_values = particle_new[3::3]

                original_str_values = str_values.copy()

                for i2 in range(10):
                    np.random.shuffle(str_values)
                    if not np.array_equal(str_values, original_str_values):
                        break

                particle_new[3::3] = str_values
                for i2 in range(5 - no_sources):
                    particle = np.hstack([particle_new, [np.nan, np.nan, np.nan]])

        weights_new = np.ones(N) / N
        return particles_result, weights_new, need_resample
    
    return particles, weights, need_resample

# Bonus: Weighted particle sample for goal-directed RL

def weighted_particle_sample(particles, weights):
    """
    Sample a particle index according to its weight (categorical sampling).
    Returns the sampled particle row.
    """
    cumulative_sum = np.cumsum(weights)  # CDF
    cumulative_sum[-1] = 1.
    index = np.searchsorted(cumulative_sum, np.random.random())
    return particles[index]

# Bonus 2: Sort particle source parameters within array by strength of source

def sort_sources_by_strength(particles):  # 3-7x faster vectorised version
    """
    Sort sources within each particle in descending order of strength.
    Particles are shaped as [num_sources, x1, y1, s1, x2, y2, s2, ...] with NaN padding.
    """
    N = particles.shape[0]
    max_sources = (particles.shape[1] - 1) // 3
    
    sources = particles[:, 1:].reshape(N, max_sources, 3)
    strength = sources[:, :, 2]
    strength_adj = np.where(np.isnan(strength), -np.inf, strength)
    sort_idx = np.argsort(-strength_adj, axis=1)
    sorted_sources = np.take_along_axis(sources, sort_idx[..., None], axis=1)
    
    particles_new = np.empty_like(particles)
    particles_new[:, 0] = particles[:, 0]
    particles_new[:, 1:] = sorted_sources.reshape(N, -1)
    
    return particles_new
