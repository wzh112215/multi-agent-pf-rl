# mixing_network.py

import torch
import torch.nn as nn
import torch.nn.functional as F

class MixingNetwork(nn.Module):
    """
    QMIX mixing network: combines local agent Q-values into a global Q_total.
    Weights are generated from the global state (via hypernetworks), ensuring Q_total
    is a monotonic function of the agent Q-values.
    """
    def __init__(self, n_agents, state_dim, hidden_dim=256):
        super(MixingNetwork, self).__init__()
        self.n_agents = n_agents
        self.state_dim = state_dim
        self.hidden_dim = hidden_dim

        # First-layer hypernetwork: generates w1 for agent Q weights
        self.hyper_w1 = nn.Linear(state_dim, n_agents * hidden_dim)
        self.hyper_b1 = nn.Linear(state_dim, hidden_dim)

        # Second-layer hypernetwork: generates w2 for the output layer
        self.hyper_w2 = nn.Linear(state_dim, hidden_dim)
        self.hyper_b2 = nn.Sequential(
            nn.Linear(state_dim, 1),
            nn.Sigmoid()  # Constrain bias range for stability
        )

    def forward(self, agent_qs, state):
        """
        Parameters:
        agent_qs: local Q-values from each agent, shape [batch_size, n_agents]
        state: global state, shape [batch_size, state_dim]

        Returns:
        q_total: mixed global Q-value, shape [batch_size, 1]
        """
        batch_size = agent_qs.size(0)

        # First layer weights and bias (generated dynamically)
        w1 = torch.abs(self.hyper_w1(state))  # [batch, n_agents * hidden_dim]
        w1 = w1.view(batch_size, self.n_agents, self.hidden_dim)
        b1 = self.hyper_b1(state).view(batch_size, 1, self.hidden_dim)

        # Mix agent_qs → hidden
        # agent_qs.unsqueeze(1): [batch, 1, n_agents]
        # bmm with w1: [batch, 1, hidden_dim]
        hidden = torch.bmm(agent_qs.unsqueeze(1), w1) + b1
        hidden = F.relu(hidden)

        # Second layer weights and bias
        w2 = torch.abs(self.hyper_w2(state)).view(batch_size, self.hidden_dim, 1)
        b2 = self.hyper_b2(state).view(batch_size, 1, 1)

        # Final global Q_total
        q_total = torch.bmm(hidden, w2) + b2  # [batch, 1, 1]
        return q_total.view(-1, 1)            # [batch_size, 1]
