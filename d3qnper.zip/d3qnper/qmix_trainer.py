# qmix_trainer.py —— Double-QMIX + PER (aligned with D3QN hyperparameters and usage)
import torch
import torch.nn as nn
import torch.optim as optim
import torch.nn.functional as F
from collections import namedtuple
import numpy as np
import random

from mixing_network import MixingNetwork

# ===========================================================
# JointTransition: one sample contains all agents' states / actions / rewards / next_states / dones / individual_rewards
#   - states, next_states:  list, length n_agents, each element shape=[1, obs_dim]
#   - actions:              list, length n_agents, each element shape=[1, 1] (discrete action index)
#   - rewards:              global reward, shape=[1, 1]
#   - dones:                termination flag, shape=[1, 1] (bool)
#   - individual_rewards:   tensor shape=[n_agents, 1]
# ===========================================================
JointTransition = namedtuple(
    'JointTransition',
    ('states', 'actions', 'rewards', 'next_states', 'dones', 'individual_rewards')
)

# ===================== Prioritized Experience Replay (PER) for joint transitions =====================
class PrioritizedJointReplayBuffer:
    """
    PER setup aligned with D3QN (O(N) implementation):
      - Sampling probability: P(i) ∝ p_i^α, p_i = |TD| + ε
      - Importance sampling: w_i = (N * P(i))^{-β} / max_j(...)
      - New sample priority = current maximum priority
    """
    def __init__(self, capacity: int, alpha: float = 0.6):
        self.capacity = capacity
        self.alpha = alpha
        self.memory = []
        self.priorities = np.zeros((capacity,), dtype=np.float32)
        self.pos = 0

    def __len__(self):
        return len(self.memory)

    def push(self, *args):
        jt = JointTransition(*args)
        max_prio = self.priorities.max() if self.memory else 1.0
        if len(self.memory) < self.capacity:
            self.memory.append(jt)
        else:
            self.memory[self.pos] = jt
        self.priorities[self.pos] = max_prio
        self.pos = (self.pos + 1) % self.capacity

    def sample(self, batch_size: int, beta: float = 0.4):
        valid_len = len(self.memory)
        prios = self.priorities[:valid_len]
        probs = prios ** self.alpha
        s = probs.sum()
        if s == 0 or not np.isfinite(s):
            probs = np.ones_like(probs, dtype=np.float32) / float(valid_len)
        else:
            probs = probs / s

        replace = valid_len < batch_size
        indices = np.random.choice(valid_len, batch_size, p=probs, replace=replace)
        samples = [self.memory[idx] for idx in indices]

        weights = (valid_len * probs[indices]) ** (-beta)
        weights = weights / weights.max()
        return samples, indices, weights

    def update_priorities(self, indices, new_priorities):
        for idx, prio in zip(indices, new_priorities):
            p = float(prio)
            if not np.isfinite(p):
                p = 1.0
            self.priorities[idx] = max(p, 1e-6)


# ====================== QMIX Trainer: Double-QMIX + PER ======================
class QMIXTrainer:
    def __init__(self, agents, mixing_network, state_dim, device,
                 memory_capacity=10000, batch_size=32, gamma=0.99, lr=1e-3, tau=0.005,
                 per_alpha=0.6, per_beta_start=0.4, per_beta_frames=100_000, per_eps=1e-5):
        """
        agents:            list of agents containing policy_net / target_net (each agent's network may be dueling)
        mixing_network:    current mixing network (MixingNetwork)
        state_dim:         global state dimension (usually = n_agents * obs_dim)
        device:            "cuda" / "cpu"
        memory_capacity:   capacity of joint replay buffer
        batch_size:        batch size
        gamma:             discount factor
        lr:                learning rate
        tau:               soft update coefficient
        per_*:             PER α/β/annealing steps/ε (aligned with D3QN defaults)
        """
        self.agents = agents
        self.n_agents = len(agents)
        self.device = device
        self.batch_size = batch_size
        self.gamma = gamma
        self.tau = tau

        self.mixing_net = mixing_network.to(device)
        self.target_mixing_net = MixingNetwork(self.n_agents, state_dim).to(device)
        self.target_mixing_net.load_state_dict(self.mixing_net.state_dict())
        self.target_mixing_net.eval()

        self.buffer = PrioritizedJointReplayBuffer(memory_capacity, alpha=per_alpha)
        self.per_alpha = per_alpha
        self.per_beta_start = per_beta_start
        self.per_beta_frames = per_beta_frames
        self.per_eps = per_eps

        self.all_params = list(self.mixing_net.parameters())
        for agent in agents:
            self.all_params += list(agent.policy_net.parameters())
        self.optimizer = optim.AdamW(self.all_params, lr=lr, amsgrad=True)

        self.loss_fn = nn.MSELoss(reduction='none')

    # PER β annealing (linear to 1.0)
    def _per_beta(self, steps_done: int) -> float:
        t = min(1.0, float(steps_done) / float(self.per_beta_frames))
        return self.per_beta_start + t * (1.0 - self.per_beta_start)

    def store_transition(self, states, action_tensors, reward, next_states, done, individual_rewards):
        self.buffer.push(states, action_tensors, reward, next_states, done, individual_rewards)

    def update(self, steps_done: int):
        if len(self.buffer) < self.batch_size:
            return

        # PER sample
        beta = self._per_beta(steps_done)
        samples, indices, is_weights_np = self.buffer.sample(self.batch_size, beta=beta)
        batch = JointTransition(*zip(*samples))

        # Prepare tensors
        state_batch = torch.stack([torch.cat(s, dim=0) for s in batch.states]).to(self.device).float()
        next_state_batch = torch.stack([torch.cat(s, dim=0) for s in batch.next_states]).to(self.device).float()
        action_batch = torch.stack([torch.cat(a, dim=0).squeeze(1) for a in batch.actions]).to(self.device).long()
        reward_batch = torch.stack(batch.rewards, dim=0).squeeze(-1).to(self.device).float()
        done_batch = torch.stack(batch.dones).squeeze(-1).to(self.device).float()
        individual_rewards_batch = torch.stack(batch.individual_rewards, dim=0).to(self.device).float()
        is_weights = torch.tensor(is_weights_np, device=self.device, dtype=torch.float32).view(-1, 1)

        # Current Q_tot
        agent_qs = []
        for i, agent in enumerate(self.agents):
            q_values = agent.policy_net(state_batch[:, i, :])
            q_selected = q_values.gather(1, action_batch[:, i].unsqueeze(1))
            agent_qs.append(q_selected)
        agent_qs = torch.cat(agent_qs, dim=1)
        global_states = state_batch.view(self.batch_size, -1)
        q_total = self.mixing_net(agent_qs, global_states)

        # Target Q_tot (Double-QMIX: policy selects a*, target evaluates Q')
        with torch.no_grad():
            target_agent_qs = []
            for i, agent in enumerate(self.agents):
                q_next_policy = agent.policy_net(next_state_batch[:, i, :])
                next_actions = q_next_policy.max(1, keepdim=True)[1]
                q_next_target = agent.target_net(next_state_batch[:, i, :])
                q_next_double = q_next_target.gather(1, next_actions)
                target_agent_qs.append(q_next_double)

            target_agent_qs = torch.cat(target_agent_qs, dim=1)
            global_next_states = next_state_batch.view(self.batch_size, -1)
            q_total_target = self.target_mixing_net(target_agent_qs, global_next_states)
            q_total_expected = reward_batch + self.gamma * q_total_target * (1.0 - done_batch)

        # Global loss (MSE per-sample + IS weights)
        per_sample_global_loss = self.loss_fn(q_total, q_total_expected.detach()).view(-1, 1)
        weighted_global_loss = (is_weights * per_sample_global_loss).mean()

        # Individual auxiliary Double-TD (accumulate per-sample)
        per_sample_indiv_loss = torch.zeros((self.batch_size, 1), device=self.device, dtype=torch.float32)
        for i, agent in enumerate(self.agents):
            q_values = agent.policy_net(state_batch[:, i, :])
            q_taken = q_values.gather(1, action_batch[:, i].unsqueeze(1))
            with torch.no_grad():
                q_next_policy = agent.policy_net(next_state_batch[:, i, :])
                next_actions = q_next_policy.max(1, keepdim=True)[1]
                q_next_target = agent.target_net(next_state_batch[:, i, :])
                next_q_double = q_next_target.gather(1, next_actions)
                reward_i = individual_rewards_batch[:, i]
                target_q_i = reward_i + self.gamma * next_q_double * (1.0 - done_batch)
            per_agent_loss = F.smooth_l1_loss(q_taken, target_q_i, reduction='none')
            per_sample_indiv_loss += per_agent_loss

        alpha = 0.0
        weighted_indiv_loss = (is_weights * per_sample_indiv_loss).mean()
        total_loss = weighted_global_loss + alpha * weighted_indiv_loss

        # Backpropagation
        self.optimizer.zero_grad()
        total_loss.backward()
        torch.nn.utils.clip_grad_norm_(self.all_params, 10)
        self.optimizer.step()

        # Update PER priorities using global TD error
        with torch.no_grad():
            td_errors = (q_total_expected - q_total).abs().view(-1).detach().cpu().numpy()
            new_prios = td_errors + self.per_eps
        self.buffer.update_priorities(indices, new_prios)

        # Soft update target networks
        self._soft_update()
        for agent in self.agents:
            agent.soft_update_target_network()

    def _soft_update(self):
        """Polyak averaging: θ' ← (1-τ)·θ' + τ·θ"""
        for tgt_p, p in zip(self.target_mixing_net.parameters(), self.mixing_net.parameters()):
            tgt_p.data.copy_((1.0 - self.tau) * tgt_p.data + self.tau * p.data)

    def get_alpha(self, steps_done: int) -> float:
        """
        Individual loss weight scheduling:
          - [0, 30k)    → 1.0
          - [30k, 60k)  → 0.5
          - [60k, +∞)   → 0.3
        """
        if steps_done < 30000:
            return 1.0
        elif steps_done < 60000:
            return 0.5
        else:
            return 0.3
