import torch
import torch.nn as nn 
import torch.optim as optim
import torch.nn.functional as F 
import numpy as np
from statsmodels.stats.weightstats import DescrStatsW 
import random
import math
import pandas as pd
import matplotlib.pyplot as plt
from matplotlib.colors import LogNorm
import matplotlib.collections as collections
from collections import namedtuple, deque
from itertools import count
import pickle
import os
# plt.ion()

# ========= custom modules =========
from environment import MultiAgentRadiationEnv
import particle as pf
from D3QN import DQNAgent
from mixing_network import MixingNetwork
from qmix_trainer import QMIXTrainer

# Variables to control display/saving of results
displayPlot = True
displaySimulation = True
displaySimulation_p = 100  # period (episodic) where simulation is displayed
savePlot = True

device = torch.device(
    "cuda" if torch.cuda.is_available() else
    "mps" if torch.backends.mps.is_available() else
    "cpu"
)
print(f"Using {device} device")
num_episodes = 1000 if torch.cuda.is_available() or torch.backends.mps.is_available() else 500

grid_size = 50
search_area_x = grid_size
search_area_y = grid_size
min_radiation_level = 100
max_radiation_level = 200
min_no_sources = 1
max_no_sources = 5
sd_noise_pct = 0.10

num_agents = 4
num_sources = 1

# ========= init environment =========
env = MultiAgentRadiationEnv(
    grid_size, num_agents, num_sources=1, move_dist=1,
    radioactivity_range=(min_radiation_level, max_radiation_level),
    noise_pct=sd_noise_pct,
    fixed_sources=[(30, 42, 104)],
    fixed_agent_positions=[
        (7, 12),
        (21, 10),
        (31, 9),
        (43, 11)
    ]
)

agent_positions = []

# Create clipped array with mesh of radiation level
rad_x = np.linspace(0, 50, 100)
rad_y = np.linspace(0, 50, 100)
rad_X, rad_Y = np.meshgrid(rad_x, rad_y)

rad_Z = np.zeros_like(rad_X)
for src in env.sources:
    rad_Z += src.radiation_level_plot(rad_X, rad_Y)
Z_clipped = np.clip(rad_Z, 0, 200)

actions = [
    [
        ag.moveUp,
        ag.moveDown,
        ag.moveLeft,
        ag.moveRight
    ]
    for ag in env.agents
]

# =============================================
# init particles/weights per agent
# =============================================

# - N: number of particles per agent
N = 500

particles_per_agent = []
weights_per_agent = []

# === create particles & weights for each agent ===
for agent_idx in range(num_agents):
    particles_i = pf.create_uniform_particles(
        (0, search_area_x),
        (0, search_area_y),
        (min_radiation_level, max_radiation_level),
        (min_no_sources, max_no_sources),
        N
    )

    # sort sources within particles by strength (desc)
    particles_i = pf.sort_sources_by_strength(particles_i)

    # uniform weights
    weights_i = np.ones(N) / N

    particles_per_agent.append(particles_i)
    weights_per_agent.append(weights_i)


# =====================================================
# init belief state (mean + variance) per agent
# =====================================================

mean_no_sources = (min_no_sources + max_no_sources) / 2

belief_state_mean_per_agent = []
belief_state_var_per_agent = []

for agent_idx in range(num_agents):
    mean_i = torch.cat([
        torch.tensor([mean_no_sources]),
        torch.tensor([
            search_area_x / 2,
            search_area_y / 2,
            (min_radiation_level + max_radiation_level) / 2
        ]).repeat(int(mean_no_sources)),
        torch.tensor([np.nan, np.nan, np.nan]).repeat(max_no_sources - int(mean_no_sources))
    ])

    var_i = torch.cat([
        torch.tensor([mean_no_sources]),
        torch.tensor([0.25, 0.25, 0.25]).repeat(int(mean_no_sources)),
        torch.tensor([np.nan, np.nan, np.nan]).repeat(max_no_sources - int(mean_no_sources))
    ])

    belief_state_mean_per_agent.append(mean_i)
    belief_state_var_per_agent.append(var_i)

# =====================================================
# history records (belief states per agent)
# =====================================================

belief_state_mean_over_time_per_agent = [
    torch.zeros(0, 3 * max_no_sources + 1, dtype=torch.float32)
    for _ in range(num_agents)
]

belief_state_var_over_time_per_agent = [
    torch.zeros(0, 3 * max_no_sources + 1, dtype=torch.float32)
    for _ in range(num_agents)
]

window_size = 25

moving_average_queue_mean_per_agent = [
    deque(maxlen=window_size)
    for _ in range(num_agents)
]

moving_average_queue_var_per_agent = [
    deque(maxlen=window_size)
    for _ in range(num_agents)
]

convergence_stable_per_agent = [
    [False] * max_no_sources
    for _ in range(num_agents)
]

episode_converged_per_agent = [
    [0] * max_no_sources
    for _ in range(num_agents)
]

convergence_tracking_per_agent = [
    [0] * max_no_sources
    for _ in range(num_agents)
]

unstable_tracking_per_agent = [
    [0] * max_no_sources
    for _ in range(num_agents)
]

meanconvergence_stable_per_agent = [[False for _ in range(num_sources)] for _ in range(num_agents)]
episode_meanconverged_per_agent = [[None for _ in range(num_sources)] for _ in range(num_agents)]
meanconvergence_tracking_per_agent = [[0 for _ in range(num_sources)] for _ in range(num_agents)]
meanunstable_tracking_per_agent = [[0 for _ in range(num_sources)] for _ in range(num_agents)]

plot_x_1 = []
plot_x_2 = []
plot_x_3 = []

# ========= hyper-parameters ========= #
BATCH_SIZE = 32
GAMMA = 0.99
EPS_START = 1.0
EPS_END = 0
EPS_DECAY = 90000

TAU = 0.005
LR = 0.001
GOAL_PROB = 1.0

n_actions = 4
n_observations = (search_area_x + 1) * (search_area_y + 1)

agents = [
    DQNAgent(
        n_observations,
        n_actions,
        device=device,
        memory_capacity=10000,
        batch_size=BATCH_SIZE,
        gamma=GAMMA,
        lr=LR,
        eps_start=EPS_START,
        eps_end=EPS_END,
        eps_decay=EPS_DECAY,
        tau=TAU,
        goal_prob=GOAL_PROB
    )
    for _ in range(num_agents)
]

state_dim = num_agents * n_observations
mixing_net = MixingNetwork(n_agents=num_agents, state_dim=state_dim).to(device)



qmix_trainer = QMIXTrainer(
    agents=agents,
    mixing_network=mixing_net,
    state_dim=state_dim,
    device=device,
    memory_capacity=10000,
    batch_size=BATCH_SIZE,
    gamma=GAMMA,
    lr=LR,
    tau=TAU
)
def one_hot_encode(state, n_observations):
    one_hot = torch.zeros(n_observations, dtype=torch.float32, device=device)
    one_hot[state] = 1
    return one_hot

episode_end_distances = [[] for _ in range(num_agents)]
episode_lengths = [[] for _ in range(num_agents)]

map_plotted = False
legend_plotted = False

fig_sim, ax_sim = plt.subplots(figsize=(9.6, 7.2), constrained_layout=True)
fig_d, axs_d = plt.subplots(num_agents, 1, figsize=(7, 2 * num_agents),
                            sharex=True, constrained_layout=True)
axs_d = axs_d.flatten()
fig_l, ax_l = plt.subplots(constrained_layout=True)
fig_l_e, (ax_l_e_x, ax_l_e_y) = plt.subplots(2, 1, figsize=(8, 6),
                                              sharex=True, constrained_layout=True)
fig_s_e, ax_s_e = plt.subplots(constrained_layout=True)
fig_n_e, ax_n_e = plt.subplots(constrained_layout=True)
fig_l_er, ax_l_er = plt.subplots(constrained_layout=True)

if not displaySimulation:
    plt.close(1)

if not displayPlot:
    plt.close(2)
    plt.close(3)
    plt.close(4)
    plt.close(5)
    plt.close(6)
    plt.close(7)

from matplotlib.ticker import MaxNLocator


def plot_distance(show_result=False, window_size=100):
    """
    Plot the per-episode distance to the source for each agent (moving average).
    Minimal changes: create line handles once, then only set_data; no repeated cla()/plot().
    """
    distances_t = torch.tensor(episode_end_distances, dtype=torch.float32).T  # [E, A]
    if distances_t.numel() == 0:
        return fig_d, axs_d

    num_agents_local = distances_t.shape[1]

    if show_result:
        fig_d.suptitle("Distance to Source per Agent (Final Result)",
                       fontsize=16, fontweight='regular', fontname='Arial', y=0.95)
    else:
        fig_d.suptitle("Distance to Source per Agent (Training)",
                       fontsize=16, fontweight='regular', fontname='Arial', y=0.95)

    color_list = ["#020af6", "#ea1212", "#057005", "#510498", 'purple', 'brown', 'pink', 'gray']
    convergence_threshold = 2.0

    if not hasattr(plot_distance, "lines") or len(getattr(plot_distance, "lines", [])) != num_agents_local:
        plot_distance.lines = []
        plot_distance.hlines = []
        for i in range(num_agents_local):
            (line,) = axs_d[i].plot([], [],
                                    color=color_list[i % len(color_list)],
                                    linewidth=2,
                                    label=f"Agent {i}")
            axs_d[i].grid(True, linestyle='--', alpha=0.6)
            axs_d[i].set_ylabel("Distance (m)", fontsize=11)
            axs_d[i].set_title(f"Agent {i}", fontsize=12)

            h = axs_d[i].axhline(y=convergence_threshold,
                                 linestyle='--', color='black',
                                 linewidth=2, alpha=0.9)
            plot_distance.lines.append(line)
            plot_distance.hlines.append(h)
        axs_d[-1].set_xlabel("Episode", fontsize=12)

    max_distance = float(distances_t.max().item())
    y_max = max(10.0, round(max_distance + 2))

    for i in range(num_agents_local):
        agent_series = distances_t[:, i]
        if len(agent_series) < window_size:
            running_average = torch.cumsum(agent_series, dim=0) / torch.arange(1, len(agent_series) + 1)
        else:
            prefix = torch.cumsum(agent_series[:window_size - 1], dim=0) / torch.arange(1, window_size)
            suffix = agent_series.unfold(0, window_size, 1).mean(1)
            running_average = torch.cat((prefix, suffix))

        y = running_average.cpu().numpy()
        x = np.arange(len(y))

        plot_distance.lines[i].set_data(x, y)

        axs_d[i].set_xlim(0, max(10, len(x)))
        axs_d[i].set_ylim(0, y_max)

        fine_ticks = list(range(0, 4, 2))                 # 0, 2
        coarse_ticks = list(range(10, int(y_max) + 1, 5))  # 10, 15, ...
        yticks = sorted(set(fine_ticks + coarse_ticks))
        axs_d[i].set_yticks(yticks)

    plt.pause(0.001)
    return fig_d, axs_d


def plot_length(show_result=False, window_size=100):
    """
    Episode length (steps) per agent with moving average.
    Minimal changes: create lines + threshold once, then only set_data updates.
    """
    lengths_t = torch.tensor(episode_lengths, dtype=torch.float32).T
    if lengths_t.numel() == 0:
        return fig_l, ax_l

    ax_l.set_title(
        "Result – Episode Length per Agent" if show_result else "Training – Episode Length per Agent",
        fontsize=14, fontname='Arial'
    )
    ax_l.set_xlabel("Episode", fontsize=12, fontname='Arial')
    ax_l.set_ylabel("Length of episode (steps taken)", fontsize=12, fontname='Arial')
    ax_l.grid(True, linestyle='--', alpha=0.3)

    colors = ["#020af6", "#ea1212", "#057005", "#510498", "purple", "brown"]
    max_steps = 100
    yticks = [20, 30, 40, 50, 60, 70, 80, 90, 100, 110]

    num_agents_local = lengths_t.shape[1]

    if not hasattr(plot_length, "lines") or len(getattr(plot_length, "lines", [])) != num_agents_local:
        plot_length.lines = []
        if hasattr(plot_length, "hline") and plot_length.hline in ax_l.lines:
            try: plot_length.hline.remove()
            except Exception: pass
        plot_length.hline = ax_l.axhline(y=max_steps, linestyle='--', color='black', linewidth=1.5, alpha=0.5)

        legend_handles = []
        legend_labels = []
        for i in range(num_agents_local):
            (line,) = ax_l.plot([], [], color=colors[i % len(colors)], linewidth=2, label=f"Agent {i}")
            plot_length.lines.append(line)
            legend_handles.append(line)
            legend_labels.append(f"Agent {i}")
        ax_l.legend(legend_handles, legend_labels, loc='upper right', fontsize=9)

        ax_l.set_ylim(min(yticks) - 5, max(yticks) + 15)
        ax_l.set_yticks(yticks)

    max_x = 0
    for i in range(num_agents_local):
        agent_series = lengths_t[:, i]
        if len(agent_series) < window_size:
            running_avg = torch.cumsum(agent_series, dim=0) / torch.arange(1, len(agent_series) + 1)
        else:
            prefix = torch.cumsum(agent_series[:window_size - 1], dim=0) / torch.arange(1, window_size)
            suffix = agent_series.unfold(0, window_size, 1).mean(1)
            running_avg = torch.cat((prefix, suffix))

        y = running_avg.cpu().numpy()
        x = np.arange(len(y))
        plot_length.lines[i].set_data(x, y)
        max_x = max(max_x, len(x))

    ax_l.set_xlim(0, max(10, max_x))

    plt.pause(0.001)
    return fig_l, ax_l


def plot_loc_estimate(show_result=False):
    """
    Trajectory of estimated source location per agent:
    top subplot for X (solid), bottom for Y (dashed).
    Minimal changes: create lines/legend once, then only set_data; remove tight_layout.
    """
    if show_result:
        fig_l_e.suptitle('Result: Estimated Source Location per Agent', fontsize=14, fontname='Arial')
    else:
        fig_l_e.suptitle('Training: Estimated Source Location per Agent', fontsize=14, fontname='Arial')

    yticks = [0, 10, 20, 30, 40, 50]
    ax_l_e_x.set_ylim(min(yticks), max(yticks) + 5); ax_l_e_x.set_yticks(yticks)
    ax_l_e_y.set_ylim(min(yticks), max(yticks) + 5); ax_l_e_y.set_yticks(yticks)
    ax_l_e_x.grid(True, linestyle='--', linewidth=0.5, alpha=0.7)
    ax_l_e_y.grid(True, linestyle='--', linewidth=0.5, alpha=0.7)
    ax_l_e_x.set_ylabel('X Coordinate'); ax_l_e_y.set_ylabel('Y Coordinate'); ax_l_e_y.set_xlabel('Episode')
    ax_l_e_x.tick_params(labelsize=10); ax_l_e_y.tick_params(labelsize=10)

    color_cycle = ["#020af6", "#ea1212", "#057005", "#510498"]
    line_styles = ['-', '--', '-.', ':']

    num_agents_local = num_agents

    if not hasattr(plot_loc_estimate, "x_lines") or len(getattr(plot_loc_estimate, "x_lines", [])) != num_agents_local:
        plot_loc_estimate.x_lines = []
        plot_loc_estimate.y_lines = []
        for agent_idx in range(num_agents_local):
            color = color_cycle[agent_idx % len(color_cycle)]
            (lx,) = ax_l_e_x.plot([], [], '-', linewidth=2.0, color=color, label=f"Agent {agent_idx}")
            (ly,) = ax_l_e_y.plot([], [], '--', linewidth=2.0, color=color, label=f"Agent {agent_idx}")
            plot_loc_estimate.x_lines.append(lx)
            plot_loc_estimate.y_lines.append(ly)
        ax_l_e_y.legend(fontsize=10, loc='lower right')

    max_xlen = 0
    for agent_idx in range(num_agents_local):
        estimates = belief_state_mean_over_time_per_agent[agent_idx]
        if estimates.shape[0] == 0:
            plot_loc_estimate.x_lines[agent_idx].set_data([], [])
            plot_loc_estimate.y_lines[agent_idx].set_data([], [])
            continue

        x_idx = np.arange(estimates.shape[0])
        x_coord = estimates[:, 1].cpu().numpy()
        y_coord = estimates[:, 2].cpu().numpy()

        plot_loc_estimate.x_lines[agent_idx].set_data(x_idx, x_coord)
        plot_loc_estimate.y_lines[agent_idx].set_data(x_idx, y_coord)
        max_xlen = max(max_xlen, len(x_idx))

    ax_l_e_x.set_xlim(0, max(10, max_xlen))
    ax_l_e_y.set_xlim(0, max(10, max_xlen))

    plt.pause(0.001)
    return fig_l_e, ax_l_e_x, ax_l_e_y


def plot_strength_estimate_error(show_result=False):
    """
    Dynamically plot the strength estimation error per agent.
    - Create lines and threshold line once
    - Then only set_data; no repeated cla()/plot()
    """
    ax_s_e.set_title(
        "PF-based Strength Estimation Error (Final Result)"
        if show_result else
        "PF-based Strength Estimation Error (Training Phase)"
    )
    ax_s_e.set_xlabel("Episode")
    ax_s_e.set_ylabel("Estimated Strength Error (mSv/h)")
    ax_s_e.grid(True, linestyle='--', alpha=0.3)

    colors = ["#020af6", "#ea1212", "#057005", "#510498"]
    line_styles = ['-', '--', '-.', ':']
    convergence_threshold = 3.0

    if (not hasattr(plot_strength_estimate_error, "lines") or
        len(getattr(plot_strength_estimate_error, "lines", [])) != num_agents):
        if hasattr(plot_strength_estimate_error, "hline"):
            try: plot_strength_estimate_error.hline.remove()
            except Exception: pass

        plot_strength_estimate_error.lines = []
        legend_handles, legend_labels = [], []

        for agent_idx in range(num_agents):
            (line,) = ax_s_e.plot([], [],
                                  color=colors[agent_idx % len(colors)],
                                  linestyle=line_styles[agent_idx % 4],
                                  linewidth=2.0,
                                  alpha=0.8,
                                  label=f"Agent {agent_idx}")
            plot_strength_estimate_error.lines.append(line)
            legend_handles.append(line)
            legend_labels.append(f"Agent {agent_idx}")

        plot_strength_estimate_error.hline = ax_s_e.axhline(
            y=convergence_threshold, color='black', linestyle='--', linewidth=2, alpha=0.8
        )
        ax_s_e.legend(legend_handles, legend_labels, loc='upper right', fontsize=9, frameon=True)

    max_len = 0
    max_err_overall = 0.0

    for agent_idx in range(num_agents):
        estimates = belief_state_mean_over_time_per_agent[agent_idx]
        if estimates.shape[0] == 0:
            plot_strength_estimate_error.lines[agent_idx].set_data([], [])
            continue

        true_strength = env.sources[0].source_radioactivity
        err = (estimates[:, 3] - true_strength).abs().cpu().numpy()
        x = np.arange(len(err))

        plot_strength_estimate_error.lines[agent_idx].set_data(x, err)
        max_len = max(max_len, len(x))
        if err.size:
            max_err_overall = max(max_err_overall, float(err.max()))

    if max_len > 0:
        ax_s_e.set_xlim(0, max(10, max_len))
        y_max = max_err_overall * 1.1 + 0.5
        ax_s_e.set_ylim(0, max(1.0, y_max))

        fine_ticks = list(np.arange(0, 6.5, 3.0))
        coarse_ticks = list(np.arange(10, max(10, y_max), 10))
        yticks = sorted(set(fine_ticks + coarse_ticks))
        ax_s_e.set_yticks(yticks)

    plt.pause(0.001)
    return fig_s_e, ax_s_e


def plot_number_estimate(show_result=False):
    """
    Plot estimated number of radiation sources per agent,
    with an inset zoom for the first ZOOM_EPS episodes.
    """
    ZOOM_EPS = 80

    ax_n_e.set_title(
        "Final Estimated Number of Radiation Sources (per Agent)"
        if show_result else
        "Estimated Number of Radiation Sources (per Agent)"
    )
    ax_n_e.set_xlabel("Episode")
    ax_n_e.set_ylabel("Number of sources")
    ax_n_e.grid(True, linestyle='--', alpha=0.3)

    colors = ["#020af6", "#ea1212", "#057005", "#510498"]

    if (not hasattr(plot_number_estimate, "lines")
        or len(getattr(plot_number_estimate, "lines", [])) != num_agents):
        plot_number_estimate.lines = []
        legend_handles, legend_labels = [], []
        for agent_idx in range(num_agents):
            (line,) = ax_n_e.plot([], [],
                                  color=colors[agent_idx % len(colors)],
                                  linewidth=2.0,
                                  label=f"Agent {agent_idx}")
            plot_number_estimate.lines.append(line)
            legend_handles.append(line); legend_labels.append(f"Agent {agent_idx}")
        ax_n_e.legend(legend_handles, legend_labels, loc="upper right",
                      fontsize=9, frameon=True)

    max_len = 0
    global_max = 0.0
    zoom_data = []
    for agent_idx in range(num_agents):
        estimates = belief_state_mean_over_time_per_agent[agent_idx]
        if estimates.shape[0] == 0:
            plot_number_estimate.lines[agent_idx].set_data([], [])
            zoom_data.append((np.array([]), np.array([])))
            continue

        source_no = estimates[:, 0].cpu().numpy()
        x = np.arange(len(source_no))
        plot_number_estimate.lines[agent_idx].set_data(x, source_no)
        max_len = max(max_len, len(x))
        if source_no.size:
            global_max = max(global_max, float(source_no.max()))

        z = min(ZOOM_EPS, len(x))
        zoom_data.append((x[:z], source_no[:z]))

    if max_len > 0:
        ax_n_e.set_xlim(0, max(10, max_len))
        y_top = max(float(max_no_sources), global_max) + 0.5
        ax_n_e.set_ylim(0, y_top)
        ax_n_e.set_yticks(list(range(0, int(max_no_sources) + 1)))

    if not hasattr(plot_number_estimate, "ax_inset"):
        INSET_LEFT   = 0.06
        INSET_TOP    = 0.92
        INSET_WIDTH  = 0.32
        INSET_HEIGHT = 0.36

        INSET_BOTTOM = INSET_TOP - INSET_HEIGHT

        ax_inset = ax_n_e.inset_axes([INSET_LEFT, INSET_BOTTOM, INSET_WIDTH, INSET_HEIGHT])
        ax_inset.set_facecolor('white')
        ax_inset.grid(True, linestyle=':', alpha=0.6)
        ax_inset.tick_params(labelsize=8)
        ax_inset.set_title(f'First {ZOOM_EPS} eps', fontsize=9)
        ax_inset.set_zorder(5)

        plot_number_estimate.ax_inset = ax_inset
        plot_number_estimate.inset_lines = []
        for agent_idx in range(num_agents):
            (line0,) = ax_inset.plot([], [], linewidth=1.6,
                                    color=colors[agent_idx % len(colors)])
            plot_number_estimate.inset_lines.append(line0)

    ax_inset = plot_number_estimate.ax_inset
    zmax = 0
    y_min_zoom, y_max_zoom = +1e9, -1e9
    for agent_idx, (xz, yz) in enumerate(zoom_data):
        plot_number_estimate.inset_lines[agent_idx].set_data(xz, yz)
        if xz.size:
            zmax = max(zmax, int(xz[-1]) + 1)
            y_min_zoom = min(y_min_zoom, float(np.min(yz)))
            y_max_zoom = max(y_max_zoom, float(np.max(yz)))

    if zmax > 0:
        ax_inset.set_xlim(0, min(ZOOM_EPS, zmax))
        pad = 0.05 * max(1e-6, (y_max_zoom - y_min_zoom))
        ax_inset.set_ylim(y_min_zoom - pad, y_max_zoom + pad)

    plt.pause(0.001)
    return fig_n_e, ax_n_e


def plot_loc_error(show_result=False):
    global fig_l_er, ax_l_er
    fig_l_er.clf()
    fig_l_er.set_size_inches(6, 6)
    ax_l_er = fig_l_er.subplots(4, 1, sharex=True)

    fig_l_er.suptitle(
        "Final Estimation Error to True Source" if show_result
        else "Estimation Error to True Source (Training Phase)",
        fontsize=13
    )

    try:
        fig_l_er.set_constrained_layout_pads(w_pad=0.02, h_pad=0.02, hspace=0.20, wspace=0.02)
    except Exception:
        pass

    colors = ["#020af6", "#ea1212", "#066e06", "#510498"]
    true_x = env.sources[0].x(); true_y = env.sources[0].y()
    threshold = 0.5

    for agent_idx in range(4):
        ax = ax_l_er[agent_idx]
        estimates = belief_state_mean_over_time_per_agent[agent_idx]
        if estimates.shape[0] == 0:
            ax.set_title(f"Agent {agent_idx}", loc='left', fontsize=10)
            ax.set_ylabel("Distance (m)", fontsize=9)
            ax.grid(True)
            if agent_idx != 3: ax.tick_params(labelbottom=False)
            continue

        x_est = estimates[:, 1]; y_est = estimates[:, 2]
        dist = torch.sqrt((x_est - true_x) ** 2 + (y_est - true_y) ** 2).cpu().numpy()

        ax.plot(dist, color=colors[agent_idx % len(colors)], linewidth=2.2)
        ax.axhline(y=threshold, color='black', linestyle='--', linewidth=1.5)
        ax.set_title(f"Agent {agent_idx}", loc='left', fontsize=10)
        ax.set_ylabel("Distance (m)", fontsize=9)
        ax.grid(True)
        if agent_idx != 3: ax.tick_params(labelbottom=False)

    ax_l_er[-1].set_xlabel("Episode", fontsize=10)
    plt.pause(0.001)
    return fig_l_er, ax_l_er


def plot_and_save_episode_trace(episode_idx, all_traces, agent_terminated_steps,
                                save_dir="multi_source_results/trace_results"):
    """
    Plot, per agent, the true-source distance and estimated distance vs. steps
    for a single episode, and save as a high-quality PNG. One subplot per agent.
    """
    import os
    import math
    import numpy as np
    import matplotlib.pyplot as plt

    os.makedirs(save_dir, exist_ok=True)

    num_agents = len(all_traces)

    if num_agents == 4:
        rows, cols = 2, 2
    else:
        cols = min(3, int(math.ceil(math.sqrt(num_agents))))
        rows = int(math.ceil(num_agents / cols))

    fig, axs = plt.subplots(rows, cols, figsize=(8, 6), constrained_layout=True)
    axs = np.atleast_1d(axs).flatten()

    for ax in axs[num_agents:]:
        ax.remove()

    subplot_labels = ['(a)', '(b)', '(c)', '(d)', '(e)', '(f)']

    for idx in range(num_agents):
        ax = axs[idx]

        if episode_idx >= len(all_traces[idx]) or len(all_traces[idx][episode_idx]) == 0:
            ax.set_title(f"{subplot_labels[idx]} Agent{idx}", fontsize=12)
            ax.set_xlabel("Step", fontsize=10)
            ax.set_ylabel("Distance to source", fontsize=10)
            ax.grid(True)
            continue

        trace = all_traces[idx][episode_idx]
        steps = np.arange(len(trace))
        true_distances = np.fromiter((p[0] for p in trace), dtype=float, count=len(trace))
        est_distances  = np.fromiter((p[1] for p in trace), dtype=float, count=len(trace))

        ax.plot(steps, est_distances, label="Estimated dist", color='red', linewidth=2)
        ax.plot(steps, true_distances, label="True dist", color='blue', linestyle='--', linewidth=2)

        if agent_terminated_steps is not None and idx < len(agent_terminated_steps):
            term = agent_terminated_steps[idx]
            if term is not None:
                ax.axvline(term, color='darkgreen', linestyle=':', linewidth=2.5, label="Terminated step")

        ax.set_title(f"{subplot_labels[idx]} Agent{idx}", fontsize=12)
        ax.set_xlabel("Step", fontsize=10)
        ax.set_ylabel("Distance to source", fontsize=10)
        ax.grid(True)
        ax.legend(loc='upper right', fontsize=9, frameon=False)

    fig.suptitle(f"Agent Distance to Source - Episode {episode_idx + 1}", fontsize=14)

    save_path = os.path.join(save_dir, f"trace_episode_{episode_idx + 1}.png")
    fig.savefig(save_path, bbox_inches='tight', dpi=300)
    plt.close(fig)
    print(f"[✓] Episode {episode_idx + 1} trace plot saved to: {save_path}")



pf_error_records = []
comm_pairs = {0: 1, 1: 0, 2: 3, 3: 2} 
steps_done = 0
all_episode_distance_traces = [[] for _ in range(num_agents)]
for i_episode in range(num_episodes):
    print(f"Episode {i_episode + 1}/{num_episodes}")
    agent_terminated_steps = [None for _ in range(num_agents)]
    per_step_agent_distances = [[] for _ in range(num_agents)]

    env.reset()
    for idx, src in enumerate(env.sources):
        print(f"True source {idx+1}: x={src.x():.2f}, y={src.y():.2f}, strength={src.source_radioactivity:.2f}")
    states = [one_hot_encode(ag.state(), n_observations).unsqueeze(0) for ag in env.agents]
    agent_paths = [[] for _ in range(env.num_agents)]
    goals = []
    for agent_idx in range(len(env.agents)):
        if i_episode == 0:
            goal = [search_area_x / 2, search_area_y / 2]
        else:
            belief_state_mean_np = belief_state_mean_per_agent[agent_idx].cpu().numpy()
            num_sources_est = int(((np.sum(~np.isnan(belief_state_mean_np))) - 1) / 3)
            goal_idx = random.randint(0, num_sources_est - 1)
            goal = [
                belief_state_mean_per_agent[agent_idx][3 * goal_idx + 1].item(),
                belief_state_mean_per_agent[agent_idx][3 * goal_idx + 2].item(),
            ]
        print(f"Episode {i_episode} Agent {agent_idx}: Goal selected = {goal}")
        goals.append(goal)
    print("steps_done =", steps_done)
    for t in count():
        agent_positions = []
        measured_values = []
        
        # Calculate total radiation level (from all sources)
        for agent in env.agents:
            pos = (agent.x(), agent.y())
            agent_positions.append(pos)
            rad = sum(src.radiation_level(*pos) for src in env.sources)
            rad += np.random.normal(0, sd_noise_pct * rad)
            measured_values.append(rad)
        for agent_idx in range(len(env.agents)):
            pos = agent_positions[agent_idx]
            obs_self = measured_values[agent_idx]

            # Get partner info
            partner_idx = comm_pairs[agent_idx]
            pos_partner = agent_positions[partner_idx]
            obs_partner = measured_values[partner_idx]

            particles_i = particles_per_agent[agent_idx]
            weights_i = weights_per_agent[agent_idx]

            likelihood_self = pf.likelihood(
                pos,
                particles_i,
                obs_self,
                sd_noise_pct,
                min_radiation_level,
                max_radiation_level
            )

            likelihood_partner = pf.likelihood(
                pos_partner,
                particles_i,
                obs_partner,
                sd_noise_pct,
                min_radiation_level,
                max_radiation_level
            )

            var_self = (
                belief_state_var_per_agent[agent_idx][1].item() +
                belief_state_var_per_agent[agent_idx][2].item()
            ) / 2  # position only

            var_partner = (
                belief_state_var_per_agent[partner_idx][1].item() +
                belief_state_var_per_agent[partner_idx][2].item()
            ) / 2

            inv_var_self = 1.0 / (var_self + 1e-6)
            inv_var_partner = 1.0 / (var_partner + 1e-6)

            alpha = inv_var_self / (inv_var_self + inv_var_partner)   # α ∈ [0,1]

            combined_likelihood = (likelihood_self ** alpha) * (likelihood_partner ** (1 - alpha))

            weights_i = pf.update_weights(weights_i, combined_likelihood)

        # # Step 2: per-agent particle filtering
        # for agent_idx in range(len(env.agents)):
        #     pos = agent_positions[agent_idx]
        #     particles_i = particles_per_agent[agent_idx]
        #     weights_i = weights_per_agent[agent_idx]
        #     # Step 2.2: likelihood
        #     likelihoods = pf.likelihood(
        #         pos, 
        #         particles_i, 
        #         measured_values[agent_idx], 
        #         sd_noise_pct,
        #         min_radiation_level,
        #         max_radiation_level
        #     )

        #     # Step 2.3: weight update
        #     weights_i = pf.update_weights(weights_i, likelihoods)

            # Step 2.4: resampling
            particles_i, weights_i, need_resample = pf.resampling_simple(
                particles_i,
                weights_i,
                min_no_sources,
                max_no_sources,
                min_radiation_level,
                max_radiation_level,
                EPS_START,
                EPS_END,
                EPS_DECAY,
                steps_done
            )

            # Step 2.5: sort after resampling
            if need_resample:
                particles_i = pf.sort_sources_by_strength(particles_i)

            # Step 2.6: write back
            particles_per_agent[agent_idx] = particles_i
            weights_per_agent[agent_idx] = weights_i

        dist_to_estimates = []
        individual_rewards = []
        terminated_list = []
        truncated_list = []
        reward_list = []
        chosen_actions = []
        # Decide all actions first
        for idx, agent in enumerate(env.agents):
            agent_pos = np.array([agent.x(), agent.y()])
            action = agents[idx].select_action(states[idx], agent_pos, goals[idx])
            i = int(action.item())
            chosen_actions.append(i)
        # Execute all actions
        for idx, i in enumerate(chosen_actions):
            actions[idx][i]()
        # Collect new states & rewards
        for idx, agent in enumerate(env.agents):
            reward = -0.02
            agent_paths[idx].append((agent.x(), agent.y()))

            est_mean = belief_state_mean_per_agent[idx]
            est_x = est_mean[1].item()
            est_y = est_mean[2].item()

            dist_to_estimate = np.linalg.norm(
                np.array([est_x, est_y]) - np.array([agent.x(), agent.y()])
            )
            dist_to_estimates.append(dist_to_estimate)
            true_distance = env.sources[0].distance(agent.x(), agent.y())
            per_step_agent_distances[idx].append([true_distance, dist_to_estimate])

            if (
                dist_to_estimate <= 2.0
                and convergence_stable_per_agent[idx][0]
            ):
                terminated = True
                truncated = False
                reward = 0.20 * measured_values[idx]
                print(f"Agent {idx}: Reached target, reward={reward:.3f}")
                if agent_terminated_steps[idx] is None:
                    agent_terminated_steps[idx] = agent.count()

            elif agent.count() >= 100:
                terminated = False
                truncated = True
                reward = 0.05 * (56 - dist_to_estimate)
                print(f"Agent {idx}: Step limit reached, reward={reward:.3f}")
                if agent_terminated_steps[idx] is None:
                    agent_terminated_steps[idx] = agent.count()

            elif not agent.actionPossible():
                terminated = False
                truncated = False
                reward = -0.0025 * est_mean[3].item()
                print(f"Agent {idx}: Action not possible, penalty applied.")
            else:
                terminated = False
                truncated = False

            individual_distance_penalty = -0.01 * dist_to_estimate

            # 80% reward, 20% distance penalty
            lambda_weight = 0.8
            final_reward_scalar = lambda_weight * reward + (1 - lambda_weight) * individual_distance_penalty

            reward_tensor = torch.tensor([final_reward_scalar], device=device)

            individual_rewards.append(final_reward_scalar)
            terminated_list.append(terminated)
            truncated_list.append(truncated)
            reward_list.append(reward_tensor)
            
        steps_done += 1
        # Episode ends if all agents terminated or truncated
        done = all(terminated or truncated for terminated, truncated in zip(terminated_list, truncated_list))

        # Visualization update
        if ((i_episode + 1) % displaySimulation_p == 0 or (i_episode + 1) == 1) and displaySimulation:
            for artist in ax_sim.get_children():
                if isinstance(artist, plt.Line2D) or isinstance(artist, collections.PathCollection):
                    artist.remove()

            if not map_plotted:
                contour = ax_sim.contourf(
                    rad_X, rad_Y, Z_clipped,
                    levels=np.logspace(np.log10(0.01), np.log10(1000), num=400),
                    cmap='cividis',
                    norm=LogNorm(vmin=0.01, vmax=1000),
                    zorder=0
                )
                cbar = fig_sim.colorbar(contour, ax=ax_sim)
                cbar.set_label('Equivalent dose rate (mSv/h)')
                cbar.set_ticks([0.01, 0.1, 1, 10, 100, 1000])

                map_plotted = True
            colors = ['red', 'black', 'white', 'yellow']
            for s_idx, src in enumerate(env.sources):
                color = colors[s_idx % len(colors)]
                label = r'$I_0 = {}$'.format(src.source_radioactivity)
                ax_sim.scatter(
                    src.x(), src.y(),
                    marker='P',
                    s=200,
                    edgecolors=color,
                    facecolors='none',
                    linewidths=1.5, 
                    zorder=3,
                    label=label
                )
            if not legend_plotted:
                legend1 = ax_sim.legend(
                    loc='upper left',
                    bbox_to_anchor=(0, 1),
                    title='True sources',
                    fontsize=8,
                    title_fontsize=8,
                    frameon=True,
                    facecolor='white',
                    framealpha=0.8,
                    borderpad=0.5
                )
                ax_sim.add_artist(legend1)
                legend_plotted = True

            agent_paths[idx].append((agent.x(), agent.y()))
            vivid_colors = ['red', 'orange', 'lime', 'cyan', 'magenta', 'yellow', 'white']
            for idx, agent in enumerate(env.agents):
                for pos in agent_paths[idx]:
                    ax_sim.plot(
                        pos[0],
                        pos[1],
                        marker='o',
                        color=vivid_colors[idx % len(vivid_colors)],
                        markersize=2,
                        zorder=2
                    )

                ax_sim.plot(
                    agent.x(),
                    agent.y(),
                    marker='x',
                    color=vivid_colors[idx % len(vivid_colors)],
                    markersize=6,
                    zorder=2
                )
            particle_colors = ["blue", "purple", "lime", "magenta", "deepskyblue", "gold", "pink", "darkgreen"]

            src_handles = []
            src_labels = []
            for agent_idx in range(num_agents):
                particles_i = particles_per_agent[agent_idx]
                for i in range(max_no_sources):
                    source_prediction = particles_i[:, [3*i + 1, 3*i + 2]]
                    filtered_data = source_prediction[~np.isnan(source_prediction).any(axis=1)]

                    if not len(filtered_data) == 0:
                        color = particle_colors[agent_idx % len(particle_colors)]

                        scatter = ax_sim.scatter(
                            filtered_data[:,0],
                            filtered_data[:,1],
                            marker='.',
                            s=4,
                            color=color,
                            alpha=0.6,
                            zorder=2
                        )

                        label = f"A{agent_idx+1}-Src{i+1}"

                        src_handles.append(scatter)
                        src_labels.append(label)

            ax_sim.legend(
                handles=src_handles,
                labels=src_labels,
                title="Estimated sources (per Agent)",
                loc='lower left',
                bbox_to_anchor=(0, 0),
                markerscale=4,
                fontsize=8,
                title_fontsize=8,
                frameon=True,
                facecolor='white',
                framealpha=0.8,
                borderpad=0.5
            )
            ax_sim.set_xlim(0, search_area_x)
            ax_sim.set_ylim(0, search_area_y)
            plt.pause(0.000001)
            # Save .png image of simulation plot
            if savePlot and done:
                sub_dir = "multi_source_results"
                sim_sub_dir = "simulation_results"
                full_dir = os.path.join(sub_dir, sim_sub_dir)

                os.makedirs(sub_dir, exist_ok=True)
                os.makedirs(full_dir, exist_ok=True)
                
                fig_sim.savefig(os.path.join(full_dir, f"episode_{i_episode + 1}"), bbox_inches='tight')
        if done:
            next_state = None
            for agent_idx in range(num_agents):
                particles_i = particles_per_agent[agent_idx]
                weights_i = weights_per_agent[agent_idx]

                (all_STE_x_mean, all_STE_y_mean, all_STE_strength_mean,
                 all_STE_x_var, all_STE_y_var, all_STE_strength_var) = pf.estimate(particles_i, weights_i)
                num_sources_int = particles_i[:,0].astype(int)

                bins = [0.5, 1.5, 2.5, 3.5, 4.5, 5.5]  # 6 bin edges for source no. prediction counts from 1 to 5

                source_counts, bins = np.histogram(num_sources_int, bins=bins)
                non_avg_belief_state_mean = []
                # First value: the index of the max value of source_counts, +1 (since it's 1-indexed)
                non_avg_belief_state_mean.append(np.argmax(source_counts) + 1)

                for i in range(max_no_sources):
                    non_avg_belief_state_mean.append(all_STE_x_mean[i])
                    non_avg_belief_state_mean.append(all_STE_y_mean[i])
                    non_avg_belief_state_mean.append(all_STE_strength_mean[i])

                non_avg_belief_state_mean = torch.tensor(non_avg_belief_state_mean, dtype=torch.float32)

                moving_average_queue_mean_per_agent[agent_idx].append(non_avg_belief_state_mean)

                belief_state_mean_per_agent[agent_idx] = torch.mean(
                    torch.stack(list(moving_average_queue_mean_per_agent[agent_idx])),
                    dim=0
                )
                non_avg_belief_state_var = []
                source_no_beliefs = np.arange(min_no_sources, max_no_sources + 1)
                non_avg_belief_state_var.append(DescrStatsW(source_no_beliefs, weights=source_counts).std)
                for i in range(max_no_sources):
                    non_avg_belief_state_var.append(all_STE_x_var[i])
                    non_avg_belief_state_var.append(all_STE_y_var[i])
                    non_avg_belief_state_var.append(all_STE_strength_var[i])

                non_avg_belief_state_var = torch.tensor(non_avg_belief_state_var, dtype=torch.float32)

                moving_average_queue_var_per_agent[agent_idx].append(non_avg_belief_state_var)

                belief_state_var_per_agent[agent_idx] = torch.mean(
                    torch.stack(list(moving_average_queue_var_per_agent[agent_idx])),
                    dim=0
                )
                tolerance_loc = 5.0
                tolerance_str = 5.0
                tolerance_no = 0.60

                source_no_stable = np.sqrt(belief_state_var_per_agent[agent_idx][0].item()) < tolerance_no

                for i in range(num_sources):
                    idx_start = 1 + i * 3

                    is_stable = (
                        source_no_stable and
                        np.sqrt(belief_state_var_per_agent[agent_idx][idx_start + 0].item()) < tolerance_loc and
                        np.sqrt(belief_state_var_per_agent[agent_idx][idx_start + 1].item()) < tolerance_loc and
                        np.sqrt(belief_state_var_per_agent[agent_idx][idx_start + 2].item()) < tolerance_str
                    )

                    if is_stable:
                        if not convergence_stable_per_agent[agent_idx][i]:
                            convergence_tracking_per_agent[agent_idx][i] += 1
                            if convergence_tracking_per_agent[agent_idx][i] >= 20:
                                episode_converged_per_agent[agent_idx][i] = i_episode
                                convergence_stable_per_agent[agent_idx][i] = True
                    else:
                        convergence_tracking_per_agent[agent_idx][i] = 0
                        if convergence_stable_per_agent[agent_idx][i]:
                            unstable_tracking_per_agent[agent_idx][i] += 1
                            if unstable_tracking_per_agent[agent_idx][i] >= 10:
                                convergence_stable_per_agent[agent_idx][i] = False
                                
                        else:
                            unstable_tracking_per_agent[agent_idx][i] = 0

                    if convergence_stable_per_agent[agent_idx][i]:
                        if i == 0:
                            plot_x_1.append(i_episode)

                    est_source_no = belief_state_mean_per_agent[agent_idx][0].item()
                    true_source_no = num_sources
                    source_no_error = abs(est_source_no - true_source_no)
                    source_no_std = np.sqrt(belief_state_var_per_agent[agent_idx][0].item())

                    idx_start = 1 + i * 3

                    est_x = belief_state_mean_per_agent[agent_idx][idx_start + 0].item()
                    est_y = belief_state_mean_per_agent[agent_idx][idx_start + 1].item()
                    est_strength = belief_state_mean_per_agent[agent_idx][idx_start + 2].item()

                    true_x = env.sources[i].x()
                    true_y = env.sources[i].y()
                    true_strength = env.sources[i].strength()

                    mean_position_error = np.sqrt((est_x - true_x) ** 2 + (est_y - true_y) ** 2)
                    mean_strength_error = abs(est_strength - true_strength)

                    std_x = np.sqrt(belief_state_var_per_agent[agent_idx][idx_start + 0].item())
                    std_y = np.sqrt(belief_state_var_per_agent[agent_idx][idx_start + 1].item())
                    std_strength = np.sqrt(belief_state_var_per_agent[agent_idx][idx_start + 2].item())

                    pf_error_records.append({
                        "Episode": i_episode,
                        "Agent": agent_idx,
                        "SourceIdx": i,
                        "": "",
                        "Source_Num_Error": source_no_error,
                        "Source_Num_Std": source_no_std,
                        " ": "",
                        "Pos_Error": mean_position_error,
                        "Std_X": std_x,
                        "Std_Y": std_y,
                        "  ": "",
                        "Strength_Error": mean_strength_error,
                        "Std_Strength": std_strength
                    })

                    if convergence_stable_per_agent[agent_idx][i]:

                        est_source_no = belief_state_mean_per_agent[agent_idx][0].item()
                        true_source_no = num_sources
                        source_no_error = abs(est_source_no - true_source_no)
                        tolerance_mean_no = 0.5

                        est_x = belief_state_mean_per_agent[agent_idx][idx_start + 0].item()
                        est_y = belief_state_mean_per_agent[agent_idx][idx_start + 1].item()
                        est_strength = belief_state_mean_per_agent[agent_idx][idx_start + 2].item()

                        true_x = env.sources[i].x()
                        true_y = env.sources[i].y()
                        true_strength = env.sources[i].strength()

                        mean_position_error = np.sqrt((est_x - true_x) ** 2 + (est_y - true_y) ** 2)
                        mean_strength_error = abs(est_strength - true_strength)

                        tolerance_mean_loc = 2.0
                        tolerance_mean_str = 3.0

                        is_mean_converged = (
                            source_no_error <= tolerance_mean_no and
                            mean_position_error <= tolerance_mean_loc and
                            mean_strength_error <= tolerance_mean_str
                        )

                        if is_mean_converged:
                            meanconvergence_tracking_per_agent[agent_idx][i] += 1
                            if meanconvergence_tracking_per_agent[agent_idx][i] >= 10:
                                if not meanconvergence_stable_per_agent[agent_idx][i]:
                                    meanconvergence_stable_per_agent[agent_idx][i] = True
                                    episode_meanconverged_per_agent[agent_idx][i] = i_episode
                        else:
                            meanconvergence_tracking_per_agent[agent_idx][i] = 0

                            if meanconvergence_stable_per_agent[agent_idx][i]:
                                meanunstable_tracking_per_agent[agent_idx][i] += 1
                                if meanunstable_tracking_per_agent[agent_idx][i] >= 5:
                                    meanconvergence_stable_per_agent[agent_idx][i] = False
                                    
                            else:
                                meanunstable_tracking_per_agent[agent_idx][i] = 0
            print(
                f"[Agent {agent_idx}] Estimated number of sources: "
                f"{belief_state_mean_per_agent[agent_idx][0]:.2f} ± {np.sqrt(belief_state_var_per_agent[agent_idx][0].item()):.2f}"
            )
            for i in range(num_sources):
                idx = 1 + i * 3
                x_mean = belief_state_mean_per_agent[agent_idx][idx].item()
                y_mean = belief_state_mean_per_agent[agent_idx][idx + 1].item()
                str_mean = belief_state_mean_per_agent[agent_idx][idx + 2].item()

                x_std = np.sqrt(belief_state_var_per_agent[agent_idx][idx].item())
                y_std = np.sqrt(belief_state_var_per_agent[agent_idx][idx + 1].item())
                str_std = np.sqrt(belief_state_var_per_agent[agent_idx][idx + 2].item())

                converged = convergence_stable_per_agent[agent_idx][i]
                track_count = convergence_tracking_per_agent[agent_idx][i]
                print(
                    f"  Source {i+1}: x={x_mean:.2f} ± {x_std:.2f}, "
                    f"y={y_mean:.2f} ± {y_std:.2f}, "
                    f"strength={str_mean:.2f} ± {str_std:.2f} | "
                    f"Converged: {converged} ({track_count}/25)"
                )

            print("  Source no. counts:", end=" ")
            for k in range(len(source_counts)):
                print(f"{k+1}:{source_counts[k]} ", end="")
            print("\n")
        else:
            # If the episode has not ended, continue: sample next_state for each agent and assemble joint experience
            next_states = []
            action_tensors = []
            for idx, agent in enumerate(env.agents):
                # Get next observation state of current agent (one-hot encoding)
                observation = agent.state()
                next_state = one_hot_encode(observation, n_observations).unsqueeze(0)
                next_states.append(next_state)

                # Current action, reward
                action_tensor = torch.tensor([[chosen_actions[idx]]], device=device, dtype=torch.long)
                action_tensors.append(action_tensor)

            # Use global reward (e.g., reward_list is each agent’s reward)    
            global_reward = sum(reward_list)  # Or a more complex aggregation
            rewards = torch.tensor([[global_reward]], device=device, dtype=torch.float32)  # [1,1]
            individual_rewards_tensor = torch.tensor(reward_list, device=device).view(num_agents, 1)

            # dones: stored at each step, termination indicated by `done` (boolean tensor)
            dones = torch.tensor([[done]], device=device)  # shape = [1, 1]

            # Store joint transition (each of shape [1, obs_dim], [1, 1])
            qmix_trainer.store_transition(states, action_tensors, rewards, next_states, dones, individual_rewards=individual_rewards_tensor)

            # Update states
            states = next_states
            # Joint training: update mixing net and all agents’ policy & target networks
            qmix_trainer.update(steps_done)
                    
        if done:  
            for idx, ag in enumerate(env.agents):
                distance_to_source = env.sources[0].distance(ag.x(), ag.y())
                episode_end_distances[idx].append(distance_to_source)
                terminated_step = agent_terminated_steps[idx]
                if terminated_step is None:
                    episode_lengths[idx].append(ag.count())
                else:
                    episode_lengths[idx].append(terminated_step)
            print(f"[Episode {i_episode+1}] Terminated steps: {agent_terminated_steps}")
            for idx in range(num_agents):
                all_episode_distance_traces[idx].append(per_step_agent_distances[idx])
                if ((i_episode + 1) == 1 or (i_episode + 1) % displaySimulation_p == 0) and savePlot:
                    if all(len(all_episode_distance_traces[i]) >= (i_episode + 1) for i in range(num_agents)):
                        plot_and_save_episode_trace(
                            episode_idx=i_episode,
                            all_traces=all_episode_distance_traces,
                            agent_terminated_steps=agent_terminated_steps
                        )

            records = []
            for agent_idx in range(num_agents):
                for source_idx in range(num_sources):
                    var_conv = episode_converged_per_agent[agent_idx][source_idx]
                    mean_conv = episode_meanconverged_per_agent[agent_idx][source_idx]
                                
                    records.append({
                        'Agent': agent_idx,
                        'Source': source_idx,
                        'Var_Converged_Episode': var_conv if var_conv is not None else -1,
                        'Mean_Converged_Episode': mean_conv if mean_conv is not None else -1,
                    })

            df_conv = pd.DataFrame(records)

            valid_var_convs = df_conv[df_conv['Var_Converged_Episode'] != -1]['Var_Converged_Episode']
            valid_mean_convs = df_conv[df_conv['Mean_Converged_Episode'] != -1]['Mean_Converged_Episode']

            avg_var_conv = valid_var_convs.mean() if not valid_var_convs.empty else -1
            avg_mean_conv = valid_mean_convs.mean() if not valid_mean_convs.empty else -1

            df_conv.loc[len(df_conv)] = {
                'Agent': 'Average',
                'Source': '-',
                'Var_Converged_Episode': round(avg_var_conv, 1),
                'Mean_Converged_Episode': round(avg_mean_conv, 1)
            }

            for agent_idx in range(num_agents):
                mean_tensor = belief_state_mean_per_agent[agent_idx].unsqueeze(0)
                var_tensor = belief_state_var_per_agent[agent_idx].unsqueeze(0)

                belief_state_mean_over_time_per_agent[agent_idx] = torch.cat(
                    [belief_state_mean_over_time_per_agent[agent_idx], mean_tensor], dim=0
                )
                belief_state_var_over_time_per_agent[agent_idx] = torch.cat(
                    [belief_state_var_over_time_per_agent[agent_idx], var_tensor], dim=0
                )

            if displayPlot:
                fig_d, axs_d = plot_distance()
                fig_l, ax_l = plot_length()
                fig_l_e, ax_l_e_x, ax_l_e_y = plot_loc_estimate()
                fig_s_e, ax_s_e = plot_strength_estimate_error()
                fig_n_e, ax_n_e = plot_number_estimate()
                fig_l_er, ax_l_er = plot_loc_error()
                                
            if savePlot: 
                current_dir = os.getcwd()
                sub_dir = "multi_source_results"

                os.makedirs(sub_dir, exist_ok=True)

                with open(os.path.join(sub_dir, "distance_plot.pkl"), "wb") as file:
                    pickle.dump((fig_d, axs_d), file)

                with open(os.path.join(sub_dir,"length_plot.pkl"), "wb") as file:
                    pickle.dump((fig_l, ax_l), file)

                with open(os.path.join(sub_dir,"location_plot.pkl"), "wb") as file:
                    pickle.dump((fig_l_e,ax_l_e_x, ax_l_e_y), file)

                with open(os.path.join(sub_dir,"strength_error_plot.pkl"), "wb") as file:
                    pickle.dump((fig_s_e, ax_s_e), file)

                with open(os.path.join(sub_dir,"number_plot.pkl"), "wb") as file:
                    pickle.dump((fig_n_e, ax_n_e), file)

                with open(os.path.join(sub_dir,"error_plot.pkl"), "wb") as file:
                    pickle.dump((fig_l_er, ax_l_er), file)
                            
                try:
                    fig_d.savefig(os.path.join(sub_dir,"dist"), bbox_inches='tight')
                    fig_l.savefig(os.path.join(sub_dir,"length"), bbox_inches='tight')
                    fig_l_e.savefig(os.path.join(sub_dir,"coords"), bbox_inches='tight')
                    fig_s_e.savefig(os.path.join(sub_dir,"est_strengths"), bbox_inches='tight')
                    fig_n_e.savefig(os.path.join(sub_dir,"num_sources"), bbox_inches='tight')
                    fig_l_er.savefig(os.path.join(sub_dir,"estimation_error"), bbox_inches='tight')
                except:
                    print("Couldn't save .png figures!")

                folder_path = os.path.join(current_dir, sub_dir)
                print(f"Files saved at: {folder_path}")

                episode_rows = list(zip(*episode_end_distances))
                df = pd.DataFrame(episode_rows, columns=[f"Agent_{i}" for i in range(num_agents)])
                df=df.round(6)
                df.to_csv(os.path.join(sub_dir, "episode_end_distances.csv"), index_label="Episode")

                length_rows = list(zip(*episode_lengths))
                df_lengths = pd.DataFrame(length_rows, columns=[f"Agent_{i}" for i in range(num_agents)])

                csv_path = os.path.join(sub_dir, "episode_lengths.csv")
                df_lengths.to_csv(csv_path, index_label="Episode")

                per_agent_mean = df_lengths.mean(axis=0, numeric_only=True).round(2)

                with open(csv_path, "a", encoding="utf-8", newline="") as f:
                    avg_row = "Average," + ",".join(str(v) for v in per_agent_mean.tolist()) + "\n"
                    f.write(avg_row)

                df_conv.to_csv(os.path.join(sub_dir, "convergence_record.csv"), index=False)
                df_pf_errors = pd.DataFrame(pf_error_records)
                df_pf_errors = df_pf_errors.round(5)
                df_pf_errors.to_csv(os.path.join(sub_dir,"pf_error_records.csv"), index=False)

            break

print('Complete')
plot_distance(show_result=True)
plot_length(show_result=True)
plot_loc_estimate(show_result=True)
plot_strength_estimate_error(show_result=True)
plot_number_estimate(show_result=True)
plot_loc_error(show_result=True)

if savePlot: 
    current_dir = os.getcwd()
    sub_dir = "multi_source_results"

    os.makedirs(sub_dir, exist_ok=True)

    with open(os.path.join(sub_dir, "distance_plot.pkl"), "wb") as file:
        pickle.dump((fig_d, axs_d), file)

    with open(os.path.join(sub_dir,"length_plot.pkl"), "wb") as file:
        pickle.dump((fig_l, ax_l), file)

    with open(os.path.join(sub_dir,"location_plot.pkl"), "wb") as file:
        pickle.dump((fig_l_e,ax_l_e_x, ax_l_e_y), file)

    with open(os.path.join(sub_dir,"strength_error_plot.pkl"), "wb") as file:
        pickle.dump((fig_s_e, ax_s_e), file)

    with open(os.path.join(sub_dir,"number_plot.pkl"), "wb") as file:
        pickle.dump((fig_n_e, ax_n_e), file)

    with open(os.path.join(sub_dir,"error_plot.pkl"), "wb") as file:
        pickle.dump((fig_l_er, ax_l_er), file)
    
    try:
        fig_d.savefig(os.path.join(sub_dir,"dist"), dpi=300, bbox_inches='tight')
        fig_l.savefig(os.path.join(sub_dir,"length"), dpi=300,bbox_inches='tight')
        fig_l_e.savefig(os.path.join(sub_dir,"coords"), dpi=300,bbox_inches='tight')
        fig_s_e.savefig(os.path.join(sub_dir,"est_strengths"),dpi=300, bbox_inches='tight')
        fig_n_e.savefig(os.path.join(sub_dir,"num_sources"), dpi=300,bbox_inches='tight')
        fig_l_er.savefig(os.path.join(sub_dir,"estimation_error"),dpi=300, bbox_inches='tight')
    except:
        print("Couldn't save .png figures!")

    folder_path = os.path.join(current_dir, sub_dir)
    print(f"Files saved at: {folder_path}")

    episode_rows = list(zip(*episode_end_distances))
    df = pd.DataFrame(episode_rows, columns=[f"Agent_{i}" for i in range(num_agents)])
    df=df.round(6)
    df.to_csv(os.path.join(sub_dir, "episode_end_distances.csv"), index_label="Episode")

    length_rows = list(zip(*episode_lengths))
    df_lengths = pd.DataFrame(length_rows, columns=[f"Agent_{i}" for i in range(num_agents)])

    csv_path = os.path.join(sub_dir, "episode_lengths.csv")
    df_lengths.to_csv(csv_path, index_label="Episode")

    per_agent_mean = df_lengths.mean(axis=0, numeric_only=True).round(2)

    with open(csv_path, "a", encoding="utf-8", newline="") as f:
        avg_row = "Average," + ",".join(str(v) for v in per_agent_mean.tolist()) + "\n"
        f.write(avg_row)

    df_conv.to_csv(os.path.join(sub_dir, "convergence_record.csv"), index=False)
    df_pf_errors = pd.DataFrame(pf_error_records)
    df_pf_errors = df_pf_errors.round(5)
    df_pf_errors.to_csv(os.path.join(sub_dir,"pf_error_records.csv"), index=False)

plt.ioff()
plt.show()
