import numpy as np  # Provides scientific computing functions, e.g. sqrt for distance

class source:
    # Initialises source location and strength
    def __init__(self, source_x, source_y, source_radioactivity, sd_noise_pct):
        """
        Initialisation function: sets initial properties when creating a source object.
        Parameters:
        - source_x: x coordinate of the source
        - source_y: y coordinate of the source
        - source_radioactivity: radioactivity intensity
        - sd_noise_pct: standard deviation noise percentage (sensor noise)
        """
        self.source_x = source_x
        self.source_y = source_y
        self.source_radioactivity = source_radioactivity
        self.sd_noise_pct = sd_noise_pct

    def strength(self):
        """
        Returns the radioactivity intensity of the source
        """
        return self.source_radioactivity

    def x(self):
        return self.source_x
    
    def y(self):
        return self.source_y
    
    def distance(self, agent_x, agent_y):
        """
        Calculates Euclidean distance between (agent_x, agent_y) and source location.
        Formula: sqrt((x1 - x2)^2 + (y1 - y2)^2)
        """
        return np.sqrt((agent_x - self.source_x)**2 + (agent_y - self.source_y)**2)
    
    def radiation_level(self, agent_x, agent_y):
        """
        Calculates radiation intensity at a given agent location (without noise).
        Formula: intensity / distance^2 (inverse square law).
        If distance is 0, returns source_radioactivity to avoid division by zero.
        """
        if self.distance(agent_x, agent_y) == 0:
            true_radiation_level = self.source_radioactivity  # Limit at 0 m distance to source_radioactivity
        else:
            true_radiation_level = self.source_radioactivity / self.distance(agent_x, agent_y)**2
        return true_radiation_level  # (Noise is added later in the overall sum)
    
    def radiation_level_plot(self, agent_x, agent_y):  # Special function just to plot colour gradient representing radiation levels (array-safe)
        """
        Plotting-specific function that returns the radiation intensity value
        without handling noise. Typically used for heatmaps or gradient visualisations.
        """
        true_radiation_level = self.source_radioactivity / self.distance(agent_x, agent_y)**2
        return true_radiation_level  # No need to plot noise, colour gradient meant to represent true radiation levels
