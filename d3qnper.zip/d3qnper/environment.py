# environment.py
import numpy as np  # For random numbers and array operations
from agent import agent  # Import agent class
from source import source  # Import source class

class MultiAgentRadiationEnv:
    """
    Multi-agent, multi-source simulation environment.
    Encapsulates the search environment including grid, agents and sources.
    """

    def __init__(self, grid_size=50, num_agents=4, num_sources=3,
                 move_dist=1, radioactivity_range=(100, 300), noise_pct=0.1,
                 fixed_sources=None, fixed_agent_positions=None):
        """
        Environment initialisation.

        Parameters:
        - grid_size: size of the grid (e.g. 50 means 50x50 cells)
        - num_agents: number of agents
        - num_sources: number of sources
        - move_dist: step distance per agent move
        - radioactivity_range: random range for source intensity
        - noise_pct: observation noise percentage
        """
        self.grid_size = grid_size
        self.num_agents = num_agents
        self.num_sources = num_sources
        self.move_dist = move_dist
        self.radioactivity_range = radioactivity_range
        self.noise_pct = noise_pct
        self.action_space = 4

        # Create agents
        self.agents = []
        if fixed_agent_positions is not None:
            for pos in fixed_agent_positions:
                ag = agent(
                    init_x=pos[0],
                    init_y=pos[1],
                    search_area_x=self.grid_size,
                    search_area_y=self.grid_size,
                    moveDist=self.move_dist
                )
                self.agents.append(ag)
        else:
            agent_segment_width = self.grid_size / self.num_agents
            for i in range(self.num_agents):
                x_start = i * agent_segment_width
                x_end = (i + 1) * agent_segment_width
                x = int(np.round(np.random.uniform(x_start+5, x_end-3)))
                y = int(np.round(np.random.uniform(8, 12)))
                ag = agent(
                    init_x=x,
                    init_y=y,
                    search_area_x=self.grid_size,
                    search_area_y=self.grid_size,
                    moveDist=self.move_dist
                )
                self.agents.append(ag)

        # Create sources
        self.sources = []
        if fixed_sources is not None:
            for sx, sy, strength in fixed_sources:
                src = source(
                    source_x=sx,
                    source_y=sy,
                    source_radioactivity=strength,
                    sd_noise_pct=self.noise_pct
                )
                self.sources.append(src)
        else:
            source_segment_width = self.grid_size / self.num_sources
            for i in range(self.num_sources):
                x_start = i * source_segment_width
                x_end = (i + 1) * source_segment_width
                sx = int(np.round(np.random.uniform(x_start+2, x_end-2)))
                sy = int(np.round(np.random.uniform(35, 49)))
                strength = int(np.round(np.random.uniform(*self.radioactivity_range)))
                src = source(
                    source_x=sx,
                    source_y=sy,
                    source_radioactivity=strength,
                    sd_noise_pct=self.noise_pct
                )
                self.sources.append(src)

    def reset(self):
        """
        Resets all agents to initial positions without regenerating new agents or sources.
        """
        for ag in self.agents:
            ag.reset()
        self.steps = 0
        return self._get_obs()

    def _get_obs(self):
        """
        Collect and return each agent's observation:
        - its own position
        - radiation intensity at its location
        - positions of other agents
        """
        obs = []
        for i, ag in enumerate(self.agents):
            ag_x = ag.x()
            ag_y = ag.y()

            radiation = sum(
                s.radiation_level(ag_x, ag_y) for s in self.sources
            )

            other_agents = [
                (o.x(), o.y()) for j, o in enumerate(self.agents) if j != i
            ]

            obs_i = {
                "position": (ag_x, ag_y),
                "radiation": radiation,
                "other_agents": other_agents
            }
            obs.append(obs_i)
        return obs

    def step(self, actions):
        """
        Receives all agents' actions, executes movements, updates step count.
        Returns: observations.
        """
        for ag, act in zip(self.agents, actions):
            if act == 0:
                ag.moveUp()
            elif act == 1:
                ag.moveDown()
            elif act == 2:
                ag.moveLeft()
            elif act == 3:
                ag.moveRight()

        self.steps += 1
        return self._get_obs()


# Example usage
# import numpy as np
# from environment import MultiAgentRadiationEnv
#
# env = MultiAgentRadiationEnv(
#     grid_size=10,
#     num_agents=3,
#     num_sources=1,
#     move_dist=1
# )
#
# observations = env.reset()
# print("=== After reset ===")
# for idx, ag in enumerate(env.agents):
#     print(f"Agent{idx} initial position: {ag.x(), ag.y()}, moveCount={ag.moveCount}")
# print(f"Total steps = {env.steps}")
#
# actions = [0, 3, 2]
# obs = env.step(actions)
# print("\n=== After first step ===")
# for idx, ag in enumerate(env.agents):
#     print(f"Agent{idx} position: {ag.x(), ag.y()}, moveCount={ag.moveCount}")
# print(f"Total steps = {env.steps}")


# Visualisation example
# import numpy as np
# import matplotlib.pyplot as plt
# from matplotlib.colors import LogNorm
# from environment import MultiAgentRadiationEnv
#
# env = MultiAgentRadiationEnv(
#     grid_size=50,
#     num_agents=5,
#     num_sources=3,
#     move_dist=1,
#     radioactivity_range=(80, 120),
#     noise_pct=0.1
# )
#
# obs = env.reset()
# rad_x = np.linspace(0, env.grid_size, 100)
# rad_y = np.linspace(0, env.grid_size, 100)
# rad_X, rad_Y = np.meshgrid(rad_x, rad_y)
# rad_Z = np.zeros_like(rad_X)
# for s in env.sources:
#     rad_Z += s.radiation_level_plot(rad_X, rad_Y)
# Z_clipped = np.clip(rad_Z, 0, 200)
#
# fig, ax = plt.subplots(figsize=(6,6))
# contour = ax.contourf(
#     rad_X, rad_Y, Z_clipped,
#     levels=np.logspace(np.log10(0.01), np.log10(1000), num=400),
#     cmap='viridis',
#     norm=LogNorm(vmin=0.01, vmax=1000)
# )
#
# cbar = fig.colorbar(contour, ax=ax)
# cbar.set_label('Equivalent dose rate (mSv/h)')
# cbar.set_ticks([0.01,0.1,1,10,100,1000])
#
# for idx, s in enumerate(env.sources):
#     ax.scatter(
#         s.x(), s.y(),
#         marker='*', s=200,
#         edgecolors='red',
#         facecolors='none',
#         zorder=3,
#         label=f"Source {idx+1}"
#     )
#
# agent_colors = ['cyan','orange','lime','yellow','pink']
# for i, ag in enumerate(env.agents):
#     ax.plot(
#         ag.x(), ag.y(),
#         marker='o',
#         color=agent_colors[i % len(agent_colors)],
#         markersize=8,
#         linestyle='None',
#         label=f"Agent {i+1}"
#     )
#
# ax.legend(loc='lower left')
# ax.set_title('Multi-Agent Radiation Environment Initialization')
# ax.grid(True)
# plt.show()
#
# env = MultiAgentRadiationEnv(
#     grid_size=10,
#     num_agents=3,
#     num_sources=2,
#     move_dist=1,
#     radioactivity_range=(100, 300),
#     noise_pct=0.1
# )
# observations = env.reset()
# print("=== Initial observations ===")
# for idx, obs in enumerate(observations):
#     print(f"Agent{idx}: position={obs['position']}, radiation={obs['radiation']:.2f}, others={obs['other_agents']}")
#
# actions = [0, 3, 2]
# observations = env.step(actions)
# print("\n=== After first step ===")
# for idx, obs in enumerate(observations):
#     print(f"Agent{idx}: position={obs['position']}, radiation={obs['radiation']:.2f}, others={obs['other_agents']}")
#
# actions = [1, 1, 1]
# observations = env.step(actions)
# print("\n=== After second step ===")
# for idx, obs in enumerate(observations):
#     print(f"Agent{idx}: position={obs['position']}, radiation={obs['radiation']:.2f}, others={obs['other_agents']}")
